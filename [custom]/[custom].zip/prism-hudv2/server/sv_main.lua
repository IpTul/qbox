local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = Config
L0_1 = L0_1.Stress
if L0_1 then
  L0_1 = Config
  L0_1 = L0_1.Stress
  L0_1 = L0_1.Enabled
  if false ~= L0_1 then
    goto lbl_28
  end
end
L0_1 = exports
L1_1 = "AddPlayerStress"
function L2_1()
  local L0_2, L1_2
end
L0_1(L1_1, L2_1)
L0_1 = exports
L1_1 = "RemovePlayerStress"
function L2_1()
  local L0_2, L1_2
end
L0_1(L1_1, L2_1)
L0_1 = exports
L1_1 = "SetPlayerStress"
function L2_1()
  local L0_2, L1_2
end
L0_1(L1_1, L2_1)
L0_1 = exports
L1_1 = "GetPlayerStress"
function L2_1()
  local L0_2, L1_2
  L0_2 = 0
  return L0_2
end
L0_1(L1_1, L2_1)
goto lbl_65
::lbl_28::
L0_1 = {}
function L1_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = Config
  L1_2 = L1_2.Framework
  if "qbx" == L1_2 then
    L1_2 = exports
    L1_2 = L1_2.qbx_core
    L2_2 = L1_2
    L1_2 = L1_2.GetPlayer
    L3_2 = A0_2
    L1_2 = L1_2(L2_2, L3_2)
    if not L1_2 then
      L2_2 = 0
      return L2_2
    end
    L2_2 = L1_2.PlayerData
    L2_2 = L2_2.metadata
    L2_2 = L2_2.stress
    if not L2_2 then
      L2_2 = 0
    end
    return L2_2
  else
    L1_2 = Config
    L1_2 = L1_2.Framework
    if "qb" == L1_2 then
      L1_2 = QBCore
      L1_2 = L1_2.Functions
      L1_2 = L1_2.GetPlayer
      L2_2 = A0_2
      L1_2 = L1_2(L2_2)
      if not L1_2 then
        L2_2 = 0
        return L2_2
      end
      L2_2 = L1_2.PlayerData
      L2_2 = L2_2.metadata
      L2_2 = L2_2.stress
      if not L2_2 then
        L2_2 = 0
      end
      return L2_2
    else
      L1_2 = Config
      L1_2 = L1_2.Framework
      if "esx" == L1_2 then
        L1_2 = L0_1
        L1_2 = L1_2[A0_2]
        if not L1_2 then
          L1_2 = 0
        end
        return L1_2
      end
    end
  end
  L1_2 = 0
  return L1_2
end
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  if A1_2 < 0 then
    A1_2 = 0
  end
  if A1_2 > 100 then
    A1_2 = 100
  end
  L2_2 = Config
  L2_2 = L2_2.Framework
  if "qbx" == L2_2 then
    L2_2 = exports
    L2_2 = L2_2.qbx_core
    L3_2 = L2_2
    L2_2 = L2_2.GetPlayer
    L4_2 = A0_2
    L2_2 = L2_2(L3_2, L4_2)
    if not L2_2 then
      return
    end
    L3_2 = L2_2.Functions
    L3_2 = L3_2.SetMetaData
    L4_2 = "stress"
    L5_2 = A1_2
    L3_2(L4_2, L5_2)
  else
    L2_2 = Config
    L2_2 = L2_2.Framework
    if "qb" == L2_2 then
      L2_2 = QBCore
      L2_2 = L2_2.Functions
      L2_2 = L2_2.GetPlayer
      L3_2 = A0_2
      L2_2 = L2_2(L3_2)
      if not L2_2 then
        return
      end
      L3_2 = L2_2.Functions
      L3_2 = L3_2.SetMetaData
      L4_2 = "stress"
      L5_2 = A1_2
      L3_2(L4_2, L5_2)
    else
      L2_2 = Config
      L2_2 = L2_2.Framework
      if "esx" == L2_2 then
        L2_2 = L0_1
        L2_2[A0_2] = A1_2
      end
    end
  end
  L2_2 = TriggerClientEvent
  L3_2 = "hud:client:UpdateStress"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
end
L3_1 = RegisterNetEvent
L4_1 = "prism-hud:server:GainStress"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = source
  L2_2 = type
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  if "number" ~= L2_2 or A0_2 <= 0 then
    return
  end
  L2_2 = L1_1
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = L2_1
  L4_2 = L1_2
  L5_2 = L2_2 + A0_2
  L3_2(L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "prism-hud:server:RelieveStress"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = source
  L2_2 = type
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  if "number" ~= L2_2 or A0_2 <= 0 then
    return
  end
  L2_2 = L1_1
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = L2_1
  L4_2 = L1_2
  L5_2 = L2_2 - A0_2
  L3_2(L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "prism-hud:server:SetStress"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = source
  L2_2 = type
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  if "number" ~= L2_2 then
    return
  end
  L2_2 = L2_1
  L3_2 = L1_2
  L4_2 = A0_2
  L2_2(L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = AddEventHandler
L4_1 = "playerDropped"
function L5_1()
  local L0_2, L1_2
  L1_2 = source
  L0_2 = L0_1
  L0_2[L1_2] = nil
end
L3_1(L4_1, L5_1)
L3_1 = exports
L4_1 = "AddPlayerStress"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = type
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if "number" ~= L2_2 or A1_2 <= 0 then
    return
  end
  L2_2 = L1_1
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L3_2 = L2_1
  L4_2 = A0_2
  L5_2 = L2_2 + A1_2
  L3_2(L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = exports
L4_1 = "RemovePlayerStress"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = type
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if "number" ~= L2_2 or A1_2 <= 0 then
    return
  end
  L2_2 = L1_1
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L3_2 = L2_1
  L4_2 = A0_2
  L5_2 = L2_2 - A1_2
  L3_2(L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = exports
L4_1 = "SetPlayerStress"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = type
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if "number" ~= L2_2 then
    return
  end
  L2_2 = L2_1
  L3_2 = A0_2
  L4_2 = A1_2
  L2_2(L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = exports
L4_1 = "GetPlayerStress"
function L5_1(A0_2)
  local L1_2, L2_2
  L1_2 = L1_1
  L2_2 = A0_2
  return L1_2(L2_2)
end
L3_1(L4_1, L5_1)
::lbl_65::
L0_1 = RegisterServerCallback
L1_1 = "prism-hudv2:GetProfilePicture"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L2_2 = promise
  L2_2 = L2_2.new
  L2_2 = L2_2()
  L3_2 = Config
  L3_2 = L3_2.Profile
  if "discord" == L3_2 then
    L3_2 = GetPlayerIdentifierByType
    L4_2 = A0_2
    L5_2 = "discord"
    L3_2 = L3_2(L4_2, L5_2)
    if L3_2 then
      L5_2 = L3_2
      L4_2 = L3_2.gsub
      L6_2 = "discord:"
      L7_2 = ""
      L4_2 = L4_2(L5_2, L6_2, L7_2)
      L3_2 = L4_2
    end
    L4_2 = string
    L4_2 = L4_2.format
    L5_2 = "https://discord.com/api/v10/users/%s"
    L6_2 = L3_2
    L4_2 = L4_2(L5_2, L6_2)
    L5_2 = PerformHttpRequest
    L6_2 = L4_2
    function L7_2(A0_3, A1_3, A2_3)
      local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
      if 200 == A0_3 then
        L3_3 = json
        L3_3 = L3_3.decode
        L4_3 = A1_3
        L3_3 = L3_3(L4_3)
        if L3_3 then
          L4_3 = L3_3.avatar
          if L4_3 then
            L4_3 = "https://cdn.discordapp.com/avatars/"
            L5_3 = L3_2
            L6_3 = "/"
            L7_3 = L3_3.avatar
            L8_3 = ".png"
            L4_3 = L4_3 .. L5_3 .. L6_3 .. L7_3 .. L8_3
            L5_3 = L2_2
            L6_3 = L5_3
            L5_3 = L5_3.resolve
            L7_3 = L4_3
            L5_3(L6_3, L7_3)
        end
        else
          L4_3 = L2_2
          L5_3 = L4_3
          L4_3 = L4_3.resolve
          L6_3 = ""
          L4_3(L5_3, L6_3)
        end
      else
        L3_3 = L2_2
        L4_3 = L3_3
        L3_3 = L3_3.resolve
        L5_3 = ""
        L3_3(L4_3, L5_3)
      end
    end
    L8_2 = "GET"
    L9_2 = ""
    L10_2 = {}
    L11_2 = "Bot "
    L12_2 = DiscordBotToken
    L11_2 = L11_2 .. L12_2
    L10_2.Authorization = L11_2
    L10_2["Content-Type"] = "application/json"
    L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
  else
    L3_2 = Config
    L3_2 = L3_2.Profile
    if "steam" == L3_2 then
      L3_2 = GetPlayerIdentifierByType
      L4_2 = A0_2
      L5_2 = "steam"
      L3_2 = L3_2(L4_2, L5_2)
      if not L3_2 then
        L5_2 = L2_2
        L4_2 = L2_2.resolve
        L6_2 = ""
        L4_2(L5_2, L6_2)
        return
      end
      L5_2 = L3_2
      L4_2 = L3_2.gsub
      L6_2 = "steam:"
      L7_2 = ""
      L4_2 = L4_2(L5_2, L6_2, L7_2)
      L3_2 = L4_2
      L4_2 = tonumber
      L5_2 = L3_2
      L6_2 = 16
      L4_2 = L4_2(L5_2, L6_2)
      if not L4_2 then
        L6_2 = L2_2
        L5_2 = L2_2.resolve
        L7_2 = ""
        L5_2(L6_2, L7_2)
        return
      end
      L5_2 = string
      L5_2 = L5_2.format
      L6_2 = "%.0f"
      L7_2 = L4_2
      L5_2 = L5_2(L6_2, L7_2)
      L6_2 = string
      L6_2 = L6_2.format
      L7_2 = "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/?key=%s&steamids=%s"
      L8_2 = SteamApiKey
      L9_2 = L5_2
      L6_2 = L6_2(L7_2, L8_2, L9_2)
      L7_2 = PerformHttpRequest
      L8_2 = L6_2
      function L9_2(A0_3, A1_3, A2_3)
        local L3_3, L4_3, L5_3, L6_3
        if 200 == A0_3 then
          L3_3 = json
          L3_3 = L3_3.decode
          L4_3 = A1_3
          L3_3 = L3_3(L4_3)
          if L3_3 then
            L4_3 = L3_3.response
            if L4_3 then
              L4_3 = L3_3.response
              L4_3 = L4_3.players
              if L4_3 then
                L4_3 = L3_3.response
                L4_3 = L4_3.players
                L4_3 = L4_3[1]
                if L4_3 then
                  L4_3 = L3_3.response
                  L4_3 = L4_3.players
                  L4_3 = L4_3[1]
                  L4_3 = L4_3.avatarfull
                  if L4_3 then
                    L4_3 = L2_2
                    L5_3 = L4_3
                    L4_3 = L4_3.resolve
                    L6_3 = L3_3.response
                    L6_3 = L6_3.players
                    L6_3 = L6_3[1]
                    L6_3 = L6_3.avatarfull
                    L4_3(L5_3, L6_3)
                end
              end
            end
          end
          else
            L4_3 = L2_2
            L5_3 = L4_3
            L4_3 = L4_3.resolve
            L6_3 = ""
            L4_3(L5_3, L6_3)
          end
        else
          L3_3 = L2_2
          L4_3 = L3_3
          L3_3 = L3_3.resolve
          L5_3 = ""
          L3_3(L4_3, L5_3)
        end
      end
      L10_2 = "GET"
      L11_2 = ""
      L12_2 = {}
      L12_2["Content-Type"] = "application/json"
      L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
    end
  end
  L3_2 = A1_2
  L4_2 = {}
  L5_2 = Citizen
  L5_2 = L5_2.Await
  L6_2 = L2_2
  L5_2 = L5_2(L6_2)
  L4_2.profilePic = L5_2
  L3_2(L4_2)
end
L0_1(L1_1, L2_1)
