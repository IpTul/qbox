SteamApiKey = '' -- https://steamcommunity.com/dev/apikey (required for steam profile pictures)
DiscordBotToken = '' -- https://discord.com/developers/applications (required for discord profile pictures)

if Config.Framework == 'qbx' or Config.Framework == 'qb' then
    QBCore = exports['qb-core']:GetCoreObject()
elseif Config.Framework == 'esx' then
    ESX = exports['es_extended']:getSharedObject()
end

RegisterServerCallback = function (name, cb)
    if Config.Framework == 'qb' or Config.Framework == 'qbx' then
        QBCore.Functions.CreateCallback(name, cb)
    elseif Config.Framework == 'esx' then
        ESX.RegisterServerCallback(name, cb)
    end
end