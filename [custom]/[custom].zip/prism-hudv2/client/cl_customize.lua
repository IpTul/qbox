if Config.Framework == 'qbx' or Config.Framework == 'qb' then
    QBCore = exports['qb-core']:GetCoreObject()
elseif Config.Framework == 'esx' then
    ESX = exports['es_extended']:getSharedObject()
end

RegisterNetEvent('esx:playerLoaded', function()
    TriggerEvent('prism-hudv2:client:OnPlayerLoaded')
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    TriggerEvent('prism-hudv2:client:OnPlayerLoaded')
end)

GetPlayerData = function ()
    if Config.Framework == 'qbx' or Config.Framework == 'qb' then
        return QBCore.Functions.GetPlayerData()
    elseif Config.Framework == 'esx' then
        return ESX.GetPlayerData()
    end
end

GetMoney = function (PlayerData)
    if Config.Framework == 'qbx' or Config.Framework == 'qb' then
        return PlayerData.money and PlayerData.money.cash or 0
    elseif Config.Framework == 'esx' then
        if not PlayerData or not PlayerData.accounts then
            return 0
        end

        local money = 0
        for _, account in pairs(PlayerData.accounts) do
            if account.name == 'money' then
                money = account.money
            end
        end
        return money
    end
    return 0
end

GetBank = function (PlayerData)
    if Config.Framework == 'qbx' or Config.Framework == 'qb' then
        return PlayerData.money and PlayerData.money.bank or 0
    elseif Config.Framework == 'esx' then
        if not PlayerData or not PlayerData.accounts then
            return 0
        end

        local bank = 0
        for _, account in pairs(PlayerData.accounts) do
            if account.name == 'bank' then
                bank = account.money
            end
        end
        return bank
    end
    return 0
end

GetVehicleFuel = function (vehicle)
    return GetVehicleFuelLevel(vehicle)
end

function GetGameTimeInHHMM()
    local hours = GetClockHours()
    local minutes = GetClockMinutes()
    local period = hours >= 12 and 'PM' or 'AM'
    local hours12 = hours % 12
    if hours12 == 0 then hours12 = 12 end
    return string.format("%02d:%02d", hours12, minutes), period
end

function MakeHudHidden ()
    if IsPauseMenuActive() then
        return true
    end
    return false
end

GetPlayerJobAndLabel = function ()
    local jobLabel, jobName = '', ''
    if Config.Framework == 'qbx' or Config.Framework == 'qb' then
        local playerData = QBCore.Functions.GetPlayerData()
        if playerData and playerData.job then
            jobLabel = playerData.job.label or ''
            jobName = playerData.job.grade and playerData.job.grade.name or ''
        end
    elseif Config.Framework == 'esx' then
        local playerData = ESX.GetPlayerData()
        if playerData and playerData.job then
            jobLabel = playerData.job.label or ''
            jobName = playerData.job.grade_label or ''
        end
    end

    return string.format("%s (%s)", jobLabel, jobName)
end

GetStreetNames = function ()
    local PlayerPed = PlayerPedId()
    local pos = GetEntityCoords(PlayerPed)

    local hash1, hash2 = GetStreetNameAtCoord(pos.x, pos.y, pos.z)
    local street1 = GetStreetNameFromHashKey(hash1)
    local street2 = GetStreetNameFromHashKey(hash2)

    local street = street1
    if street2 and street2 ~= '' then
        street = street .. ' / ' .. street2
    end

    local zoneHash = GetNameOfZone(pos.x, pos.y, pos.z)
    local zoneName = GetLabelText(zoneHash)
    if zoneName == 'NULL' then
        zoneName = zoneHash
    end

    return street, zoneName
end

GetVoiceLevel = function (proximity)
    return proximity == 1.5 and 1 or proximity == 3.0 and 2 or proximity == 6.0 and 3 or 0
end

GetVehicleType = function (vehicle)
    local model = GetEntityModel(vehicle)
    local checks = {
        { IsThisModelABicycle, 'bicycle' },
        { IsThisModelACar, 'car' },
        { IsThisModelATrain, 'train' },
        { IsThisModelABike, 'bike' },
        { IsThisModelABoat, 'boat' },
        { IsThisModelAHeli, 'heli' },
        { IsThisModelAPlane, 'plane' },
        { IsThisModelAJetski, 'boat' },
        { IsThisModelAQuadbike, 'bike' },
        { IsThisModelAnAmphibiousCar, 'car' },
        { IsThisModelAnAmphibiousQuadbike, 'bike' },
    }
    for _, v in ipairs(checks) do
        if v[1](model) then return v[2] end
    end
    return 'unknown'
end

AwaitServerCallback = function(name, ...)
    local args = { ... }
    local promise = promise.new()
    local isResolved = false

    local function handleCallback(...)
        if not isResolved then
            isResolved = true
            promise:resolve({...})
        end
    end

    if Config.Framework == 'esx' then
        ESX.TriggerServerCallback(name, handleCallback, table.unpack(args))
    elseif Config.Framework == 'qb' or Config.Framework == 'qbx' then
        QBCore.Functions.TriggerCallback(name, handleCallback, table.unpack(args))
    else
        isResolved = true
        promise:resolve({nil})
    end

    local result = Citizen.Await(promise)
    return table.unpack(result or {nil})
end