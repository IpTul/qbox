

if Config.Stress and Config.Stress.Enabled == false then
    exports('GetStress', function() return 0 end)
    exports('SetStress', function() end)
    exports('AddStress', function() end)
    exports('RemoveStress', function() end)
    return
end

local lastHealth = 200
local effectCooldown = 0
local lastHunger = Hunger or 0
local lastThirst = Thirst or 0

local function GetMinimumStress()
    return (Config.Stress and Config.Stress.MinimumStress) or 50
end

local function GetMinimumSpeed()
    return (Config.Stress and Config.Stress.MinimumSpeed) or 100
end

local function GetShootingChance()
    return (Config.Stress and Config.Stress.ShootingChance) or 0.1
end

local function GetBlurIntensity(stressLevel)
    if Config.StressEffects and Config.StressEffects.BlurIntensity then
        for _, v in pairs(Config.StressEffects.BlurIntensity) do
            if stressLevel >= v.min and stressLevel <= v.max then
                return v.intensity
            end
        end
    end
    return math.floor(1500 + (stressLevel - 50) * 30)
end

local function GetEffectInterval(stressLevel)
    if Config.StressEffects and Config.StressEffects.EffectInterval then
        for _, v in pairs(Config.StressEffects.EffectInterval) do
            if stressLevel >= v.min and stressLevel <= v.max then
                return v.timeout
            end
        end
    end
    if stressLevel >= 90 then return 15000
    elseif stressLevel >= 80 then return 20000
    elseif stressLevel >= 70 then return 30000
    elseif stressLevel >= 60 then return 40000
    elseif stressLevel >= 50 then return 50000
    end
    return 60000
end

CreateThread(function()
    Wait(2000)
    if Config.Framework == 'qbx' or Config.Framework == 'qb' then
        local playerData = GetPlayerData()
        if playerData and playerData.metadata and playerData.metadata.stress then
            Stress = playerData.metadata.stress
        end
    elseif Config.Framework == 'esx' then
        local saved = GetResourceKvpFloat('prism_stress')
        if saved and saved > 0 then
            Stress = saved
            TriggerServerEvent('prism-hud:server:SetStress', Stress)
        end
    end
end)

if Config.Framework == 'esx' then
    CreateThread(function()
        while true do
            Wait(60000)
            SetResourceKvpFloat('prism_stress', Stress)
        end
    end)
end

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local weapon = GetSelectedPedWeapon(ped)
        if weapon ~= `WEAPON_UNARMED` then
            if IsPedShooting(ped) then
                if math.random() < GetShootingChance() then
                    TriggerServerEvent('prism-hud:server:GainStress', math.random(1, 3))
                end
            end
            Wait(100)
        else
            Wait(1000)
        end
    end
end)

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local currentHealth = GetEntityHealth(ped)
        if currentHealth < lastHealth and lastHealth > 0 then
            local damage = lastHealth - currentHealth
            if damage > 0 and damage < 100 then
                TriggerServerEvent('prism-hud:server:GainStress', math.random(3, 5))
            end
        end
        lastHealth = currentHealth
        Wait(200)
    end
end)

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            local vehicle = GetVehiclePedIsIn(ped, false)
            local speed = GetEntitySpeed(vehicle) * 2.23694 -- mph
            if speed >= GetMinimumSpeed() then
                TriggerServerEvent('prism-hud:server:GainStress', math.random(1, 3))
            end
        end
        Wait(10000)
    end
end)

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local isInVehicle = IsPedInAnyVehicle(ped, false)

        if not isInVehicle then
            if not IsPedSprinting(ped) and not IsPedRunning(ped) then
                TriggerServerEvent('prism-hud:server:RelieveStress', math.random(1, 2))
            end
        else
            local vehicle = GetVehiclePedIsIn(ped, false)
            local speed = GetEntitySpeed(vehicle) * 2.23694
            if speed < 40 then
                TriggerServerEvent('prism-hud:server:RelieveStress', math.random(1, 2))
            end
        end

        Wait(isInVehicle and 30000 or 60000)
    end
end)

CreateThread(function()
    Wait(5000)
    lastHunger = Hunger or 0
    lastThirst = Thirst or 0

    while true do
        Wait(1000)
        local currentHunger = Hunger or 0
        local currentThirst = Thirst or 0

        if currentHunger > lastHunger + 2 and Stress > 0 then
            local relief = (Config.Stress and Config.Stress.EatingRelief) or 12
            TriggerServerEvent('prism-hud:server:RelieveStress', relief)
        end

        if currentThirst > lastThirst + 2 and Stress > 0 then
            local relief = (Config.Stress and Config.Stress.DrinkingRelief) or 8
            TriggerServerEvent('prism-hud:server:RelieveStress', relief)
        end

        lastHunger = currentHunger
        lastThirst = currentThirst
    end
end)

local function PlayMaxStressEffects()
    local ped = PlayerPedId()
    local blurIntensity = GetBlurIntensity(100)
    local fallRepeat = math.random(2, 4)
    local ragdollTimeout = fallRepeat * 1750

    TriggerScreenblurFadeIn(1000.0)
    Wait(blurIntensity)
    TriggerScreenblurFadeOut(1000.0)

    local ragdollEnabled = not Config.Stress or Config.Stress.EnableRagdoll ~= false
    local ragdollChance = (Config.Stress and Config.Stress.RagdollChance) or 0.5
    if ragdollEnabled and math.random() < ragdollChance then
        if not IsPedRagdoll(ped) and IsPedOnFoot(ped) and not IsPedSwimming(ped) then
            SetPedToRagdollWithFall(ped, ragdollTimeout, ragdollTimeout, 1, GetEntityForwardVector(ped), 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        end
    end

    Wait(1000)

    for _ = 1, fallRepeat do
        Wait(750)
        DoScreenFadeOut(200)
        Wait(1000)
        DoScreenFadeIn(200)
        TriggerScreenblurFadeIn(1000.0)
        Wait(blurIntensity)
        TriggerScreenblurFadeOut(1000.0)
    end
end

local function PlayBlurEffect()
    local blurIntensity = GetBlurIntensity(Stress)
    TriggerScreenblurFadeIn(1000.0)
    Wait(blurIntensity)
    TriggerScreenblurFadeOut(1000.0)
end

-- Stress screen effects thread
CreateThread(function()
    while true do
        Wait(2000)

        local now = GetGameTimer()
        local minStress = GetMinimumStress()

        if Stress >= minStress and now >= effectCooldown then
            local interval = GetEffectInterval(Stress)

            if Stress >= 100 then
                PlayMaxStressEffects()
            elseif Stress >= minStress then
                PlayBlurEffect()
            end

            effectCooldown = GetGameTimer() + interval
        end
    end
end)

-- Debug command: /setstress [0-100]
RegisterCommand('setstress', function(_, args)
    local value = tonumber(args[1])
    if value then
        Stress = value
        if Stress < 0 then Stress = 0 end
        if Stress > 100 then Stress = 100 end
        effectCooldown = 0
        TriggerServerEvent('prism-hud:server:SetStress', Stress)
        print(('[prism-hud] Stress set to %.1f'):format(Stress))
    else
        print(('[prism-hud] Current stress: %.1f'):format(Stress))
    end
end, false)

exports('GetStress', function()
    return Stress
end)

exports('SetStress', function(value)
    if value < 0 then value = 0 end
    if value > 100 then value = 100 end
    Stress = value
    effectCooldown = 0
    TriggerServerEvent('prism-hud:server:SetStress', Stress)
end)

exports('AddStress', function(amount)
    TriggerServerEvent('prism-hud:server:GainStress', amount)
end)

exports('RemoveStress', function(amount)
    TriggerServerEvent('prism-hud:server:RelieveStress', amount)
end)
