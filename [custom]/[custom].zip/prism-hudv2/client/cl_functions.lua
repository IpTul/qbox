local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
function L0_1(A0_2)
  local L1_2, L2_2
  L1_2 = SendNUIMessage
  L2_2 = {}
  L2_2.action = "updateHud"
  L2_2.data = A0_2
  L1_2(L2_2)
end
SendHudData = L0_1
function L0_1()
  local L0_2, L1_2, L2_2
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.action = "showHud"
  L2_2 = {}
  L2_2.visibility = false
  L1_2.data = L2_2
  L0_2(L1_2)
end
HideHud = L0_1
function L0_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.action = "showHud"
  L2_2 = {}
  L2_2.visibility = true
  L3_2 = Locales
  L2_2.locales = L3_2
  L1_2.data = L2_2
  L0_2(L1_2)
end
ShowHud = L0_1
function L0_1(A0_2)
  local L1_2
  if A0_2 then
    L1_2 = ShowHud
    L1_2()
  else
    L1_2 = HideHud
    L1_2()
  end
end
ToggleHud = L0_1
EditModeVisible = false
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  if A0_2 then
    L1_2 = SendNUIMessage
    L2_2 = {}
    L2_2.action = "showHudSettings"
    L3_2 = {}
    L3_2.visibility = true
    L4_2 = Locales
    L3_2.locales = L4_2
    L4_2 = Config
    L4_2 = L4_2.PrimaryColor
    if not L4_2 then
      L4_2 = "#BEEE11"
    end
    L3_2.primaryColor = L4_2
    L2_2.data = L3_2
    L1_2(L2_2)
    L1_2 = SetNuiFocus
    L2_2 = true
    L3_2 = true
    L1_2(L2_2, L3_2)
  else
    L1_2 = SendNUIMessage
    L2_2 = {}
    L2_2.action = "showHudSettings"
    L3_2 = {}
    L3_2.visibility = false
    L2_2.data = L3_2
    L1_2(L2_2)
    L1_2 = EditModeVisible
    if not L1_2 then
      L1_2 = SetNuiFocus
      L2_2 = false
      L3_2 = false
      L1_2(L2_2, L3_2)
    end
  end
end
ToggleHudSettingsMenu = L0_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  if A0_2 then
    EditModeVisible = true
    L1_2 = SendNUIMessage
    L2_2 = {}
    L2_2.action = "showEditMode"
    L3_2 = {}
    L3_2.visibility = true
    L4_2 = Locales
    L3_2.locales = L4_2
    L2_2.data = L3_2
    L1_2(L2_2)
    L1_2 = SetNuiFocus
    L2_2 = true
    L3_2 = true
    L1_2(L2_2, L3_2)
  else
    EditModeVisible = false
    L1_2 = SendNUIMessage
    L2_2 = {}
    L2_2.action = "showEditMode"
    L3_2 = {}
    L3_2.visibility = false
    L2_2.data = L3_2
    L1_2(L2_2)
    L1_2 = SetNuiFocus
    L2_2 = false
    L3_2 = false
    L1_2(L2_2, L3_2)
  end
end
ToggleEditMode = L0_1
VehicleControlVisible = false
L0_1 = {}
L0_1.indicatorLeft = false
L0_1.indicatorRight = false
L0_1.hazard = false
L0_1.headlights = false
L1_1 = {}
L0_1.windows = L1_1
VehicleControlState = L0_1
L0_1 = {}
L0_1.enabled = false
L0_1.vehicle = nil
L0_1.targetSpeed = 0.0
L0_1.lastEngineHealth = 0
L0_1.lastIdealPedalPressure = 0.0
L0_1.increasePressure = false
L0_1.speedDiffTolerance = 0.1388888888888889
CruiseControl = L0_1
L0_1 = {}
L0_1.enabled = false
L0_1.cacheVeh = nil
L0_1.isRagdoll = false
L0_1.vehSpeed = 0.0
L1_1 = vector3
L2_1 = 0
L3_1 = 0
L4_1 = 0
L1_1 = L1_1(L2_1, L3_1, L4_1)
L0_1.previousVelocity = L1_1
L0_1.warningActive = false
Seatbelt = L0_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = Config
  L1_2 = L1_2.Seatbelt
  if L1_2 then
    L1_2 = Config
    L1_2 = L1_2.Seatbelt
    L1_2 = L1_2.VehicleClasses
    if L1_2 then
      goto lbl_12
    end
  end
  L1_2 = false
  do return L1_2 end
  ::lbl_12::
  L1_2 = ipairs
  L2_2 = Config
  L2_2 = L2_2.Seatbelt
  L2_2 = L2_2.VehicleClasses
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    if L6_2 == A0_2 then
      L7_2 = true
      return L7_2
    end
  end
  L1_2 = false
  return L1_2
end
L1_1 = Seatbelt
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = Seatbelt
  L0_2.enabled = false
  L0_2 = Seatbelt
  L0_2.cacheVeh = nil
  L0_2 = Seatbelt
  L0_2.isRagdoll = false
  L0_2 = Seatbelt
  L0_2.vehSpeed = 0.0
  L0_2 = Seatbelt
  L1_2 = vector3
  L2_2 = 0
  L3_2 = 0
  L4_2 = 0
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L0_2.previousVelocity = L1_2
  L0_2 = Seatbelt
  L0_2 = L0_2.warningActive
  if L0_2 then
    L0_2 = Seatbelt
    L0_2.warningActive = false
    L0_2 = SendNUIMessage
    L1_2 = {}
    L1_2.action = "seatbeltWarning"
    L2_2 = {}
    L2_2.enabled = false
    L1_2.data = L2_2
    L0_2(L1_2)
  end
end
L1_1.Reset = L2_1
L1_1 = Seatbelt
function L2_1()
  local L0_2, L1_2
  L0_2 = Seatbelt
  L0_2.isRagdoll = true
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    while true do
      L0_3 = Seatbelt
      L0_3 = L0_3.isRagdoll
      if not L0_3 then
        break
      end
      L0_3 = Wait
      L1_3 = 0
      L0_3(L1_3)
      L0_3 = SetPedToRagdoll
      L1_3 = PlayerPedId
      L1_3 = L1_3()
      L2_3 = 1000
      L3_3 = 1000
      L4_3 = 0
      L5_3 = false
      L6_3 = false
      L7_3 = false
      L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
    end
  end
  L0_2(L1_2)
end
L1_1.SetRagdoll = L2_1
L1_1 = Seatbelt
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = GetEntityCoords
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  L2_2 = SetEntityCoords
  L3_2 = L0_2
  L4_2 = L1_2.x
  L5_2 = L1_2.y
  L6_2 = L1_2.z
  L6_2 = L6_2 - 0.47
  L7_2 = true
  L8_2 = true
  L9_2 = true
  L10_2 = false
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
  L2_2 = SetEntityVelocity
  L3_2 = L0_2
  L4_2 = Seatbelt
  L4_2 = L4_2.previousVelocity
  L4_2 = L4_2.x
  L5_2 = Seatbelt
  L5_2 = L5_2.previousVelocity
  L5_2 = L5_2.y
  L6_2 = Seatbelt
  L6_2 = L6_2.previousVelocity
  L6_2 = L6_2.z
  L2_2(L3_2, L4_2, L5_2, L6_2)
  L2_2 = Seatbelt
  L2_2 = L2_2.SetRagdoll
  L2_2()
  L2_2 = Config
  L2_2 = L2_2.Seatbelt
  if L2_2 then
    L2_2 = Config
    L2_2 = L2_2.Seatbelt
    L2_2 = L2_2.RagdollTime
    if L2_2 then
      goto lbl_43
    end
  end
  L2_2 = 3
  ::lbl_43::
  L2_2 = L2_2 * 1000
  L3_2 = SetTimeout
  L4_2 = L2_2
  function L5_2()
    local L0_3, L1_3
    L0_3 = Seatbelt
    L0_3.isRagdoll = false
    L0_3 = Seatbelt
    L0_3 = L0_3.Reset
    L0_3()
  end
  L3_2(L4_2, L5_2)
end
L1_1.EjectSeat = L2_1
L1_1 = Seatbelt
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L0_2 = Seatbelt
  L0_2 = L0_2.cacheVeh
  if not L0_2 then
    return
  end
  L0_2 = Seatbelt
  L0_2 = L0_2.vehSpeed
  L1_2 = Seatbelt
  L2_2 = GetEntitySpeed
  L3_2 = Seatbelt
  L3_2 = L3_2.cacheVeh
  L2_2 = L2_2(L3_2)
  L1_2.vehSpeed = L2_2
  L1_2 = SetPedConfigFlag
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = 32
  L4_2 = true
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = Seatbelt
  L1_2 = L1_2.vehSpeed
  L1_2 = L1_2 * 3.6
  L2_2 = Seatbelt
  L2_2 = L2_2.enabled
  if L2_2 then
    L2_2 = Seatbelt
    L2_2 = L2_2.warningActive
    if L2_2 then
      L2_2 = Seatbelt
      L2_2.warningActive = false
      L2_2 = SendNUIMessage
      L3_2 = {}
      L3_2.action = "seatbeltWarning"
      L4_2 = {}
      L4_2.enabled = false
      L3_2.data = L4_2
      L2_2(L3_2)
    end
    return
  end
  if L1_2 > 20 then
    L2_2 = Seatbelt
    L2_2 = L2_2.warningActive
    if not L2_2 then
      L2_2 = Seatbelt
      L2_2.warningActive = true
      L2_2 = SendNUIMessage
      L3_2 = {}
      L3_2.action = "seatbeltWarning"
      L4_2 = {}
      L4_2.enabled = true
      L3_2.data = L4_2
      L2_2(L3_2)
  end
  elseif L1_2 <= 20 then
    L2_2 = Seatbelt
    L2_2 = L2_2.warningActive
    if L2_2 then
      L2_2 = Seatbelt
      L2_2.warningActive = false
      L2_2 = SendNUIMessage
      L3_2 = {}
      L3_2.action = "seatbeltWarning"
      L4_2 = {}
      L4_2.enabled = false
      L3_2.data = L4_2
      L2_2(L3_2)
    end
  end
  L2_2 = GetEntitySpeedVector
  L3_2 = Seatbelt
  L3_2 = L3_2.cacheVeh
  L4_2 = true
  L2_2 = L2_2(L3_2, L4_2)
  L2_2 = L2_2.y
  L2_2 = L2_2 > 1.0
  L3_2 = Seatbelt
  L3_2 = L3_2.vehSpeed
  L3_2 = L0_2 - L3_2
  L4_2 = GetFrameTime
  L4_2 = L4_2()
  L3_2 = L3_2 / L4_2
  L4_2 = Config
  L4_2 = L4_2.Seatbelt
  if L4_2 then
    L4_2 = Config
    L4_2 = L4_2.Seatbelt
    L4_2 = L4_2.EjectCheckSpeed
    if L4_2 then
      goto lbl_107
    end
  end
  L4_2 = 45
  ::lbl_107::
  L4_2 = L4_2 / 2.237
  L5_2 = L0_2 > L4_2
  L6_2 = 981.0
  L6_2 = L3_2 > L6_2
  if L2_2 and L5_2 and L6_2 then
    L7_2 = Seatbelt
    L7_2 = L7_2.EjectSeat
    L7_2()
  else
    L7_2 = Seatbelt
    L8_2 = GetEntityVelocity
    L9_2 = Seatbelt
    L9_2 = L9_2.cacheVeh
    L8_2 = L8_2(L9_2)
    L7_2.previousVelocity = L8_2
  end
end
L1_1.Logic = L2_1
L1_1 = Seatbelt
function L2_1()
  local L0_2, L1_2
end
L1_1.DisableExit = L2_1
L1_1 = Seatbelt
function L2_1()
  local L0_2, L1_2
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    while true do
      L0_3 = PlayerPedId
      L0_3 = L0_3()
      L1_3 = GetVehiclePedIsIn
      L2_3 = L0_3
      L3_3 = false
      L1_3 = L1_3(L2_3, L3_3)
      if 0 == L1_3 then
        L2_3 = Seatbelt
        L2_3 = L2_3.cacheVeh
        if L2_3 then
          L2_3 = Seatbelt
          L2_3 = L2_3.Reset
          L2_3()
        end
        L2_3 = Wait
        L3_3 = 500
        L2_3(L3_3)
      else
        L2_3 = Seatbelt
        L2_3 = L2_3.cacheVeh
        if L2_3 then
          L2_3 = Seatbelt
          L2_3 = L2_3.cacheVeh
          if L2_3 == L1_3 then
            goto lbl_41
          end
        end
        L2_3 = GetVehicleClass
        L3_3 = L1_3
        L2_3 = L2_3(L3_3)
        L3_3 = L0_1
        L4_3 = L2_3
        L3_3 = L3_3(L4_3)
        if L3_3 then
          L3_3 = Seatbelt
          L3_3.cacheVeh = L1_3
        else
          L3_3 = Seatbelt
          L3_3.cacheVeh = nil
        end
        ::lbl_41::
        L2_3 = Seatbelt
        L2_3 = L2_3.cacheVeh
        if L2_3 then
          L2_3 = Seatbelt
          L2_3 = L2_3.Logic
          L2_3()
        end
        L2_3 = Wait
        L3_3 = 200
        L2_3(L3_3)
      end
    end
  end
  L0_2(L1_2)
end
L1_1.Thread = L2_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = Config
  L0_2 = L0_2.Seatbelt
  if L0_2 then
    L0_2 = Config
    L0_2 = L0_2.Seatbelt
    L0_2 = L0_2.Enable
    if L0_2 then
      goto lbl_12
    end
  end
  L0_2 = false
  do return L0_2 end
  ::lbl_12::
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = GetVehiclePedIsIn
  L2_2 = L0_2
  L3_2 = false
  L1_2 = L1_2(L2_2, L3_2)
  if 0 == L1_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = GetVehicleClass
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = L0_1
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    L3_2 = false
    return L3_2
  end
  L3_2 = Seatbelt
  L4_2 = Seatbelt
  L4_2 = L4_2.enabled
  L4_2 = not L4_2
  L3_2.enabled = L4_2
  L3_2 = Seatbelt
  L3_2.cacheVeh = L1_2
  L3_2 = Seatbelt
  L3_2 = L3_2.enabled
  if L3_2 then
    L3_2 = Seatbelt
    L3_2 = L3_2.DisableExit
    L3_2()
    L3_2 = Seatbelt
    L3_2 = L3_2.warningActive
    if L3_2 then
      L3_2 = Seatbelt
      L3_2.warningActive = false
      L3_2 = SendNUIMessage
      L4_2 = {}
      L4_2.action = "seatbeltWarning"
      L5_2 = {}
      L5_2.enabled = false
      L4_2.data = L5_2
      L3_2(L4_2)
    end
    L3_2 = SendNUIMessage
    L4_2 = {}
    L4_2.action = "seatbeltSound"
    L5_2 = {}
    L5_2.type = "buckle"
    L4_2.data = L5_2
    L3_2(L4_2)
  else
    L3_2 = SendNUIMessage
    L4_2 = {}
    L4_2.action = "seatbeltSound"
    L5_2 = {}
    L5_2.type = "unbuckle"
    L4_2.data = L5_2
    L3_2(L4_2)
  end
  L3_2 = Seatbelt
  L3_2 = L3_2.enabled
  return L3_2
end
ToggleSeatbelt = L1_1
L1_1 = exports
L2_1 = "isSeatbeltOn"
function L3_1()
  local L0_2, L1_2
  L0_2 = Seatbelt
  L0_2 = L0_2.enabled
  return L0_2
end
L1_1(L2_1, L3_1)
L1_1 = exports
L2_1 = "setSeatbelt"
function L3_1(A0_2)
  local L1_2
  if A0_2 then
    L1_2 = Seatbelt
    L1_2 = L1_2.enabled
    if not L1_2 then
      L1_2 = ToggleSeatbelt
      L1_2()
    end
  else
    L1_2 = Seatbelt
    L1_2 = L1_2.enabled
    if L1_2 then
      L1_2 = ToggleSeatbelt
      L1_2()
    end
  end
end
L1_1(L2_1, L3_1)
L1_1 = {}
L1_1.active = false
BoatHorn = L1_1
L1_1 = BoatHorn
function L2_1()
  local L0_2, L1_2
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
    while true do
      L0_3 = PlayerPedId
      L0_3 = L0_3()
      L1_3 = GetVehiclePedIsIn
      L2_3 = L0_3
      L3_3 = false
      L1_3 = L1_3(L2_3, L3_3)
      if 0 ~= L1_3 then
        L2_3 = GetVehicleType
        L3_3 = L1_3
        L2_3 = L2_3(L3_3)
        if "boat" == L2_3 then
          L2_3 = IsControlPressed
          L3_3 = 0
          L4_3 = 86
          L2_3 = L2_3(L3_3, L4_3)
          if L2_3 then
            L3_3 = BoatHorn
            L3_3 = L3_3.active
            if not L3_3 then
              L3_3 = BoatHorn
              L3_3.active = true
              L3_3 = SendNUIMessage
              L4_3 = {}
              L4_3.action = "boatHorn"
              L5_3 = {}
              L5_3.enabled = true
              L4_3.data = L5_3
              L3_3(L4_3)
          end
          elseif not L2_3 then
            L3_3 = BoatHorn
            L3_3 = L3_3.active
            if L3_3 then
              L3_3 = BoatHorn
              L3_3.active = false
              L3_3 = SendNUIMessage
              L4_3 = {}
              L4_3.action = "boatHorn"
              L5_3 = {}
              L5_3.enabled = false
              L4_3.data = L5_3
              L3_3(L4_3)
            end
          end
          L3_3 = Wait
          L4_3 = 50
          L3_3(L4_3)
      end
      else
        L2_3 = BoatHorn
        L2_3 = L2_3.active
        if L2_3 then
          L2_3 = BoatHorn
          L2_3.active = false
          L2_3 = SendNUIMessage
          L3_3 = {}
          L3_3.action = "boatHorn"
          L4_3 = {}
          L4_3.enabled = false
          L3_3.data = L4_3
          L2_3(L3_3)
        end
        L2_3 = Wait
        L3_3 = 500
        L2_3(L3_3)
      end
    end
  end
  L0_2(L1_2)
end
L1_1.Thread = L2_1
L1_1 = {}
L1_1.lastRing = 0
BicycleBell = L1_1
L1_1 = BicycleBell
function L2_1()
  local L0_2, L1_2
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L0_3 = false
    while true do
      L1_3 = PlayerPedId
      L1_3 = L1_3()
      L2_3 = GetVehiclePedIsIn
      L3_3 = L1_3
      L4_3 = false
      L2_3 = L2_3(L3_3, L4_3)
      if 0 ~= L2_3 then
        L3_3 = GetVehicleType
        L4_3 = L2_3
        L3_3 = L3_3(L4_3)
        if "bicycle" == L3_3 then
          L3_3 = IsControlPressed
          L4_3 = 0
          L5_3 = 86
          L3_3 = L3_3(L4_3, L5_3)
          if L3_3 and not L0_3 then
            L4_3 = GetGameTimer
            L4_3 = L4_3()
            L5_3 = BicycleBell
            L5_3 = L5_3.lastRing
            L5_3 = L4_3 - L5_3
            L6_3 = 300
            if L5_3 > L6_3 then
              L5_3 = BicycleBell
              L5_3.lastRing = L4_3
              L5_3 = SendNUIMessage
              L6_3 = {}
              L6_3.action = "bicycleBell"
              L7_3 = {}
              L6_3.data = L7_3
              L5_3(L6_3)
            end
          end
          L0_3 = L3_3
          L4_3 = Wait
          L5_3 = 50
          L4_3(L5_3)
      end
      else
        L0_3 = false
        L3_3 = Wait
        L4_3 = 500
        L3_3(L4_3)
      end
    end
  end
  L0_2(L1_2)
end
L1_1.Thread = L2_1
L1_1 = {}
L1_1.warning = false
AircraftStall = L1_1
L1_1 = AircraftStall
function L2_1()
  local L0_2, L1_2
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    while true do
      L0_3 = PlayerPedId
      L0_3 = L0_3()
      L1_3 = GetVehiclePedIsIn
      L2_3 = L0_3
      L3_3 = false
      L1_3 = L1_3(L2_3, L3_3)
      if 0 ~= L1_3 then
        L2_3 = GetVehicleType
        L3_3 = L1_3
        L2_3 = L2_3(L3_3)
        if "plane" == L2_3 then
          L3_3 = GetEntitySpeed
          L4_3 = L1_3
          L3_3 = L3_3(L4_3)
          L4_3 = GetEntityCoords
          L5_3 = L1_3
          L4_3 = L4_3(L5_3)
          L5_3 = 0
          L6_3 = GetGroundZFor_3dCoord
          L7_3 = L4_3.x
          L8_3 = L4_3.y
          L9_3 = L4_3.z
          L10_3 = false
          L6_3, L7_3 = L6_3(L7_3, L8_3, L9_3, L10_3)
          if L6_3 then
            L5_3 = L7_3
          end
          L8_3 = L4_3.z
          L8_3 = L8_3 - L5_3
          L9_3 = 30.0
          L10_3 = L3_3 < L9_3 and L8_3 > 10
          if L10_3 then
            L11_3 = AircraftStall
            L11_3 = L11_3.warning
            if not L11_3 then
              L11_3 = AircraftStall
              L11_3.warning = true
              L11_3 = SendNUIMessage
              L12_3 = {}
              L12_3.action = "stallWarning"
              L13_3 = {}
              L13_3.enabled = true
              L12_3.data = L13_3
              L11_3(L12_3)
          end
          elseif not L10_3 then
            L11_3 = AircraftStall
            L11_3 = L11_3.warning
            if L11_3 then
              L11_3 = AircraftStall
              L11_3.warning = false
              L11_3 = SendNUIMessage
              L12_3 = {}
              L12_3.action = "stallWarning"
              L13_3 = {}
              L13_3.enabled = false
              L12_3.data = L13_3
              L11_3(L12_3)
            end
          end
          L11_3 = Wait
          L12_3 = 100
          L11_3(L12_3)
        else
          L3_3 = AircraftStall
          L3_3 = L3_3.warning
          if L3_3 then
            L3_3 = AircraftStall
            L3_3.warning = false
            L3_3 = SendNUIMessage
            L4_3 = {}
            L4_3.action = "stallWarning"
            L5_3 = {}
            L5_3.enabled = false
            L4_3.data = L5_3
            L3_3(L4_3)
          end
          L3_3 = Wait
          L4_3 = 500
          L3_3(L4_3)
        end
      else
        L2_3 = AircraftStall
        L2_3 = L2_3.warning
        if L2_3 then
          L2_3 = AircraftStall
          L2_3.warning = false
          L2_3 = SendNUIMessage
          L3_3 = {}
          L3_3.action = "stallWarning"
          L4_3 = {}
          L4_3.enabled = false
          L3_3.data = L4_3
          L2_3(L3_3)
        end
        L2_3 = Wait
        L3_3 = 500
        L2_3(L3_3)
      end
    end
  end
  L0_2(L1_2)
end
L1_1.Thread = L2_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = GetVehiclePedIsIn
  L2_2 = L0_2
  L3_2 = false
  L1_2 = L1_2(L2_2, L3_2)
  if 0 == L1_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = GetPedInVehicleSeat
  L3_2 = L1_2
  L4_2 = -1
  L2_2 = L2_2(L3_2, L4_2)
  L2_2 = L2_2 == L0_2
  return L2_2
end
function L2_1()
  local L0_2, L1_2, L2_2
  L0_2 = IsControlPressed
  L1_2 = 0
  L2_2 = 63
  L0_2 = L0_2(L1_2, L2_2)
  if not L0_2 then
    L0_2 = IsControlPressed
    L1_2 = 0
    L2_2 = 64
    L0_2 = L0_2(L1_2, L2_2)
  end
  return L0_2
end
function L3_1(A0_2)
  local L1_2, L2_2
  L1_2 = GetEntitySpeed
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L1_2 = L1_2 * 3.6
  return L1_2
end
L4_1 = CruiseControl
function L5_1()
  local L0_2, L1_2
  L0_2 = CruiseControl
  L0_2 = L0_2.enabled
  if not L0_2 then
    return
  end
  L0_2 = CruiseControl
  L0_2.enabled = false
  L0_2 = CruiseControl
  L0_2.targetSpeed = 0.0
  L0_2 = CruiseControl
  L0_2.lastEngineHealth = 0
  L0_2 = CruiseControl
  L0_2.lastIdealPedalPressure = 0.0
  L0_2 = CruiseControl
  L0_2.increasePressure = false
  L0_2 = CruiseControl
  L0_2.vehicle = nil
end
L4_1.Reset = L5_1
L4_1 = CruiseControl
function L5_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = CruiseControl
  L0_2 = L0_2.enabled
  if not L0_2 then
    return
  end
  L0_2 = CruiseControl
  L0_2 = L0_2.increasePressure
  if not L0_2 then
    L0_2 = CruiseControl
    L0_2.increasePressure = true
  end
  L0_2 = SetControlNormal
  L1_2 = 0
  L2_2 = 71
  L3_2 = CruiseControl
  L3_2 = L3_2.lastIdealPedalPressure
  L0_2(L1_2, L2_2, L3_2)
end
L4_1.ApplyIdealPedalPressure = L5_1
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = GetVehiclePedIsIn
  L2_2 = L0_2
  L3_2 = false
  L1_2 = L1_2(L2_2, L3_2)
  if 0 == L1_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = L1_1
  L2_2 = L2_2()
  if not L2_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = CruiseControl
  L2_2 = L2_2.enabled
  if L2_2 then
    L2_2 = CruiseControl
    L2_2 = L2_2.Reset
    L2_2()
    L2_2 = false
    return L2_2
  end
  L2_2 = L3_1
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if L2_2 < 20 then
    L3_2 = false
    return L3_2
  end
  L3_2 = CruiseControl
  L3_2.enabled = true
  L3_2 = CruiseControl
  L3_2.vehicle = L1_2
  L3_2 = CruiseControl
  L3_2.targetSpeed = L2_2
  L3_2 = CruiseControl
  L4_2 = GetVehicleEngineHealth
  L5_2 = L1_2
  L4_2 = L4_2(L5_2)
  L3_2.lastEngineHealth = L4_2
  L3_2 = CruiseControl
  L3_2.lastIdealPedalPressure = 0.2
  L3_2 = CreateThread
  function L4_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    while true do
      L0_3 = CruiseControl
      L0_3 = L0_3.enabled
      if not L0_3 then
        break
      end
      L0_3 = Wait
      L1_3 = 0
      L0_3(L1_3)
      L0_3 = PlayerPedId
      L0_3 = L0_3()
      L1_3 = GetVehiclePedIsIn
      L2_3 = L0_3
      L3_3 = false
      L1_3 = L1_3(L2_3, L3_3)
      if 0 ~= L1_3 then
        L2_3 = CruiseControl
        L2_3 = L2_3.vehicle
        if L1_3 == L2_3 then
          L2_3 = L1_1
          L2_3 = L2_3()
          if L2_3 then
            goto lbl_28
          end
        end
      end
      L2_3 = CruiseControl
      L2_3 = L2_3.Reset
      L2_3()
      do break end
      ::lbl_28::
      L2_3 = IsControlJustPressed
      L3_3 = 0
      L4_3 = 72
      L2_3 = L2_3(L3_3, L4_3)
      if not L2_3 then
        L2_3 = IsControlJustPressed
        L3_3 = 0
        L4_3 = 76
        L2_3 = L2_3(L3_3, L4_3)
        if not L2_3 then
          goto lbl_44
        end
      end
      L2_3 = CruiseControl
      L2_3 = L2_3.Reset
      L2_3()
      do break end
      ::lbl_44::
      L2_3 = GetVehicleEngineHealth
      L3_3 = L1_3
      L2_3 = L2_3(L3_3)
      L3_3 = CruiseControl
      L3_3 = L3_3.lastEngineHealth
      if L3_3 then
        L3_3 = CruiseControl
        L3_3 = L3_3.lastEngineHealth
        L3_3 = L3_3 - L2_3
        if L3_3 > 10 then
          L3_3 = CruiseControl
          L3_3 = L3_3.Reset
          L3_3()
          break
      end
      else
        L3_3 = CruiseControl
        L3_3.lastEngineHealth = L2_3
      end
      L3_3 = L3_1
      L4_3 = L1_3
      L3_3 = L3_3(L4_3)
      if L3_3 < 5 then
        L4_3 = CruiseControl
        L4_3 = L4_3.Reset
        L4_3()
        break
      end
      L4_3 = GetEntitySpeed
      L5_3 = L1_3
      L4_3 = L4_3(L5_3)
      L5_3 = CruiseControl
      L5_3 = L5_3.targetSpeed
      L5_3 = L5_3 / 3.6
      L6_3 = L5_3 - L4_3
      L7_3 = CruiseControl
      L7_3 = L7_3.speedDiffTolerance
      if L6_3 > L7_3 then
        L7_3 = 0.8
        L8_3 = L2_1
        L8_3 = L8_3()
        if L8_3 then
          L7_3 = 0.4
        end
        L8_3 = CruiseControl
        L8_3 = L8_3.increasePressure
        if L8_3 then
          L8_3 = CruiseControl
          L9_3 = CruiseControl
          L9_3 = L9_3.lastIdealPedalPressure
          L9_3 = L9_3 + 0.025
          L8_3.lastIdealPedalPressure = L9_3
          L8_3 = CruiseControl
          L8_3.increasePressure = false
        end
        L8_3 = SetControlNormal
        L9_3 = 0
        L10_3 = 71
        L11_3 = L7_3
        L8_3(L9_3, L10_3, L11_3)
      else
        L7_3 = CruiseControl
        L7_3 = L7_3.speedDiffTolerance
        L7_3 = 4 * L7_3
        L7_3 = -L7_3
        if L6_3 > L7_3 then
          L7_3 = CruiseControl
          L7_3 = L7_3.ApplyIdealPedalPressure
          L7_3()
        else
          L7_3 = CruiseControl
          L7_3.lastIdealPedalPressure = 0.2
        end
      end
    end
  end
  L3_2(L4_2)
  L3_2 = CruiseControl
  L3_2 = L3_2.enabled
  return L3_2
end
ToggleCruiseControl = L4_1
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = GetVehiclePedIsIn
  L2_2 = L0_2
  L3_2 = false
  L1_2 = L1_2(L2_2, L3_2)
  if 0 == L1_2 then
    L2_2 = nil
    return L2_2
  end
  L2_2 = GetVehicleClass
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = GetVehicleMaxNumberOfPassengers
  L4_2 = L1_2
  L3_2 = L3_2(L4_2)
  L3_2 = L3_2 + 1
  L4_2 = GetNumberOfVehicleDoors
  L5_2 = L1_2
  L4_2 = L4_2(L5_2)
  L5_2 = {}
  L6_2 = {}
  L7_2 = {}
  L7_2.name = "frontLeft"
  L7_2.bone = "door_dside_f"
  L7_2.index = 0
  L8_2 = {}
  L8_2.name = "frontRight"
  L8_2.bone = "door_pside_f"
  L8_2.index = 1
  L9_2 = {}
  L9_2.name = "rearLeft"
  L9_2.bone = "door_dside_r"
  L9_2.index = 2
  L10_2 = {}
  L10_2.name = "rearRight"
  L10_2.bone = "door_pside_r"
  L10_2.index = 3
  L11_2 = {}
  L11_2.name = "hood"
  L11_2.bone = "bonnet"
  L11_2.index = 4
  L12_2 = {}
  L12_2.name = "trunk"
  L12_2.bone = "boot"
  L12_2.index = 5
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  L6_2[3] = L9_2
  L6_2[4] = L10_2
  L6_2[5] = L11_2
  L6_2[6] = L12_2
  L7_2 = ipairs
  L8_2 = L6_2
  L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
  for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
    L13_2 = GetEntityBoneIndexByName
    L14_2 = L1_2
    L15_2 = L12_2.bone
    L13_2 = L13_2(L14_2, L15_2)
    if -1 ~= L13_2 then
      L14_2 = GetVehicleDoorAngleRatio
      L15_2 = L1_2
      L16_2 = L12_2.index
      L14_2 = L14_2(L15_2, L16_2)
      L14_2 = L14_2 > 0.0
      L15_2 = L12_2.name
      L16_2 = {}
      L16_2.exists = true
      L16_2.isOpen = L14_2
      L17_2 = L12_2.index
      L16_2.index = L17_2
      L5_2[L15_2] = L16_2
    end
  end
  L7_2 = L5_2.frontLeft
  if not L7_2 and L3_2 >= 1 then
    L7_2 = {}
    L7_2.exists = true
    L7_2.isOpen = false
    L7_2.index = 0
    L5_2.frontLeft = L7_2
  end
  L7_2 = L5_2.frontRight
  if not L7_2 and L3_2 >= 2 then
    L7_2 = {}
    L7_2.exists = true
    L7_2.isOpen = false
    L7_2.index = 1
    L5_2.frontRight = L7_2
  end
  L7_2 = L5_2.rearLeft
  if not L7_2 and L3_2 >= 3 then
    L7_2 = {}
    L7_2.exists = true
    L7_2.isOpen = false
    L7_2.index = 2
    L5_2.rearLeft = L7_2
  end
  L7_2 = L5_2.rearRight
  if not L7_2 and L3_2 >= 4 then
    L7_2 = {}
    L7_2.exists = true
    L7_2.isOpen = false
    L7_2.index = 3
    L5_2.rearRight = L7_2
  end
  L7_2 = {}
  L8_2 = {}
  L9_2 = {}
  L9_2.name = "frontLeft"
  L9_2.bone = "window_lf"
  L9_2.index = 0
  L10_2 = {}
  L10_2.name = "frontRight"
  L10_2.bone = "window_rf"
  L10_2.index = 1
  L11_2 = {}
  L11_2.name = "rearLeft"
  L11_2.bone = "window_lr"
  L11_2.index = 2
  L12_2 = {}
  L12_2.name = "rearRight"
  L12_2.bone = "window_rr"
  L12_2.index = 3
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  L8_2[3] = L11_2
  L8_2[4] = L12_2
  L9_2 = ipairs
  L10_2 = L8_2
  L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
  for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
    L15_2 = GetEntityBoneIndexByName
    L16_2 = L1_2
    L17_2 = L14_2.bone
    L15_2 = L15_2(L16_2, L17_2)
    if -1 ~= L15_2 then
      L16_2 = L14_2.name
      L17_2 = {}
      L17_2.exists = true
      L18_2 = L14_2.index
      L17_2.index = L18_2
      L7_2[L16_2] = L17_2
    end
  end
  L9_2 = L7_2.frontLeft
  if not L9_2 then
    L9_2 = L5_2.frontLeft
    if L9_2 then
      L9_2 = {}
      L9_2.exists = true
      L9_2.index = 0
      L7_2.frontLeft = L9_2
    end
  end
  L9_2 = L7_2.frontRight
  if not L9_2 then
    L9_2 = L5_2.frontRight
    if L9_2 then
      L9_2 = {}
      L9_2.exists = true
      L9_2.index = 1
      L7_2.frontRight = L9_2
    end
  end
  L9_2 = L7_2.rearLeft
  if not L9_2 then
    L9_2 = L5_2.rearLeft
    if L9_2 then
      L9_2 = {}
      L9_2.exists = true
      L9_2.index = 2
      L7_2.rearLeft = L9_2
    end
  end
  L9_2 = L7_2.rearRight
  if not L9_2 then
    L9_2 = L5_2.rearRight
    if L9_2 then
      L9_2 = {}
      L9_2.exists = true
      L9_2.index = 3
      L7_2.rearRight = L9_2
    end
  end
  L9_2 = GetIsVehicleEngineRunning
  L10_2 = L1_2
  L9_2 = L9_2(L10_2)
  L10_2 = GetVehicleDoorLockStatus
  L11_2 = L1_2
  L10_2 = L10_2(L11_2)
  L10_2 = 2 == L10_2
  L11_2 = 13 ~= L2_2 and 14 ~= L2_2 and 15 ~= L2_2 and 16 ~= L2_2 and 21 ~= L2_2
  L12_2 = 8 ~= L2_2 and 13 ~= L2_2 and 14 ~= L2_2 and 15 ~= L2_2 and 16 ~= L2_2 and 21 ~= L2_2
  L13_2 = 13 ~= L2_2 and 14 ~= L2_2 and 15 ~= L2_2 and 16 ~= L2_2 and 21 ~= L2_2
  L14_2 = 13 ~= L2_2
  L15_2 = {}
  L15_2.vehicle = L1_2
  L15_2.vehicleClass = L2_2
  L15_2.maxSeats = L3_2
  L15_2.doors = L5_2
  L15_2.windows = L7_2
  L15_2.engineRunning = L9_2
  L15_2.locked = L10_2
  L15_2.hasNeon = L11_2
  L15_2.hasCruiseControl = L12_2
  L15_2.hasIndicators = L13_2
  L15_2.hasHeadlights = L14_2
  return L15_2
end
GetVehicleData = L4_1
function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = GetVehiclePedIsIn
  L3_2 = L1_2
  L4_2 = false
  L2_2 = L2_2(L3_2, L4_2)
  if nil == A0_2 then
    L3_2 = VehicleControlVisible
    L3_2 = not L3_2
    VehicleControlVisible = L3_2
  else
    VehicleControlVisible = A0_2
  end
  L3_2 = VehicleControlVisible
  if L3_2 and 0 == L2_2 then
    VehicleControlVisible = false
    return
  end
  L3_2 = nil
  L4_2 = VehicleControlVisible
  if L4_2 then
    L4_2 = GetVehicleData
    L4_2 = L4_2()
    L3_2 = L4_2
  end
  L4_2 = SendNUIMessage
  L5_2 = {}
  L5_2.action = "toggleVehicleControl"
  L6_2 = {}
  L7_2 = VehicleControlVisible
  L6_2.visible = L7_2
  L6_2.vehicleData = L3_2
  L5_2.data = L6_2
  L4_2(L5_2)
  L4_2 = SetNuiFocus
  L5_2 = VehicleControlVisible
  L6_2 = VehicleControlVisible
  L4_2(L5_2, L6_2)
end
ToggleVehicleControl = L4_1
function L4_1()
  local L0_2, L1_2
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
    L0_3 = Wait
    L1_3 = 50
    L0_3(L1_3)
    L0_3 = 1.7777777777777777
    L1_3 = GetActiveScreenResolution
    L1_3, L2_3 = L1_3()
    L3_3 = L1_3 / L2_3
    L4_3 = 0
    if L0_3 < L3_3 then
      L5_3 = L0_3 - L3_3
      L5_3 = L5_3 / 3.6
      L4_3 = L5_3 - 0.008
    end
    L5_3 = 0
    L6_3 = 0
    L7_3 = MinimapPosition
    if L7_3 then
      L7_3 = MinimapPosition
      L7_3 = L7_3.x
      L7_3 = L7_3 - 19
      L5_3 = L7_3 / 1920
      L7_3 = MinimapPosition
      L7_3 = L7_3.y
      L7_3 = L7_3 - 880
      L6_3 = L7_3 / 1080
    end
    L7_3 = HudSettings
    L7_3 = L7_3.minimapStyle
    if not L7_3 then
      L7_3 = "squaremap"
    end
    if "squaremap" == L7_3 then
      L8_3 = RequestStreamedTextureDict
      L9_3 = "squaremap"
      L10_3 = false
      L8_3(L9_3, L10_3)
      while true do
        L8_3 = HasStreamedTextureDictLoaded
        L9_3 = "squaremap"
        L8_3 = L8_3(L9_3)
        if L8_3 then
          break
        end
        L8_3 = Wait
        L9_3 = 100
        L8_3(L9_3)
      end
      L8_3 = SetMinimapClipType
      L9_3 = 0
      L8_3(L9_3)
      L8_3 = AddReplaceTexture
      L9_3 = "platform:/textures/graphics"
      L10_3 = "radarmasksm"
      L11_3 = "squaremap"
      L12_3 = "radarmasksm"
      L8_3(L9_3, L10_3, L11_3, L12_3)
      L8_3 = AddReplaceTexture
      L9_3 = "platform:/textures/graphics"
      L10_3 = "radarmask1g"
      L11_3 = "squaremap"
      L12_3 = "radarmasksm"
      L8_3(L9_3, L10_3, L11_3, L12_3)
      L8_3 = SetMinimapComponentPosition
      L9_3 = "minimap"
      L10_3 = "L"
      L11_3 = "B"
      L12_3 = -0.005 + L4_3
      L12_3 = L12_3 + L5_3
      L13_3 = -0.032 + L6_3
      L14_3 = 0.128
      L15_3 = 0.143
      L8_3(L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
      L8_3 = SetMinimapComponentPosition
      L9_3 = "minimap_mask"
      L10_3 = "L"
      L11_3 = "B"
      L12_3 = -0.005 + L4_3
      L12_3 = L12_3 + L5_3
      L13_3 = 0.0 + L6_3
      L14_3 = 0.1
      L15_3 = 0.156
      L8_3(L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
      L8_3 = SetMinimapComponentPosition
      L9_3 = "minimap_blur"
      L10_3 = "L"
      L11_3 = "B"
      L12_3 = -0.012 + L4_3
      L12_3 = L12_3 + L5_3
      L13_3 = 0.02 + L6_3
      L14_3 = 0.205
      L15_3 = 0.235
      L8_3(L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
      L8_3 = SetBlipAlpha
      L9_3 = GetNorthRadarBlip
      L9_3 = L9_3()
      L10_3 = 0
      L8_3(L9_3, L10_3)
      L8_3 = SetRadarBigmapEnabled
      L9_3 = true
      L10_3 = false
      L8_3(L9_3, L10_3)
      L8_3 = SetMinimapClipType
      L9_3 = 0
      L8_3(L9_3)
      L8_3 = Wait
      L9_3 = 50
      L8_3(L9_3)
      L8_3 = SetRadarBigmapEnabled
      L9_3 = false
      L10_3 = false
      L8_3(L9_3, L10_3)
    elseif "circlemap" == L7_3 then
      L8_3 = RequestStreamedTextureDict
      L9_3 = "circlemap"
      L10_3 = false
      L8_3(L9_3, L10_3)
      while true do
        L8_3 = HasStreamedTextureDictLoaded
        L9_3 = "circlemap"
        L8_3 = L8_3(L9_3)
        if L8_3 then
          break
        end
        L8_3 = Wait
        L9_3 = 100
        L8_3(L9_3)
      end
      L8_3 = SetMinimapClipType
      L9_3 = 1
      L8_3(L9_3)
      L8_3 = AddReplaceTexture
      L9_3 = "platform:/textures/graphics"
      L10_3 = "radarmasksm"
      L11_3 = "circlemap"
      L12_3 = "radarmasksm"
      L8_3(L9_3, L10_3, L11_3, L12_3)
      L8_3 = AddReplaceTexture
      L9_3 = "platform:/textures/graphics"
      L10_3 = "radarmask1g"
      L11_3 = "circlemap"
      L12_3 = "radarmasksm"
      L8_3(L9_3, L10_3, L11_3, L12_3)
      L8_3 = SetMinimapComponentPosition
      L9_3 = "minimap"
      L10_3 = "L"
      L11_3 = "B"
      L12_3 = -0.017 + L4_3
      L12_3 = L12_3 + L5_3
      L13_3 = -0.002 + L6_3
      L14_3 = 0.135
      L15_3 = 0.193
      L8_3(L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
      L8_3 = SetMinimapComponentPosition
      L9_3 = "minimap_mask"
      L10_3 = "L"
      L11_3 = "B"
      L12_3 = 0.14 + L4_3
      L12_3 = L12_3 + L5_3
      L13_3 = 0.02 + L6_3
      L14_3 = 0.048
      L15_3 = 0.15
      L8_3(L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
      L8_3 = SetMinimapComponentPosition
      L9_3 = "minimap_blur"
      L10_3 = "L"
      L11_3 = "B"
      L12_3 = -0.01 + L4_3
      L12_3 = L12_3 + L5_3
      L13_3 = 0.031 + L6_3
      L14_3 = 0.188
      L15_3 = 0.253
      L8_3(L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
      L8_3 = SetBlipAlpha
      L9_3 = GetNorthRadarBlip
      L9_3 = L9_3()
      L10_3 = 0
      L8_3(L9_3, L10_3)
      L8_3 = SetMinimapClipType
      L9_3 = 1
      L8_3(L9_3)
      L8_3 = SetRadarBigmapEnabled
      L9_3 = true
      L10_3 = false
      L8_3(L9_3, L10_3)
      L8_3 = Wait
      L9_3 = 50
      L8_3(L9_3)
      L8_3 = SetRadarBigmapEnabled
      L9_3 = false
      L10_3 = false
      L8_3(L9_3, L10_3)
    end
  end
  L0_2(L1_2)
end
LoadMinimapStyle = L4_1
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  while true do
    L0_2 = UiReady
    if L0_2 then
      break
    end
    L0_2 = Wait
    L1_2 = 0
    L0_2(L1_2)
  end
  L0_2 = GetPlayerData
  L0_2 = L0_2()
  PlayerData = L0_2
  while true do
    L0_2 = PlayerData
    if L0_2 then
      break
    end
    L0_2 = Wait
    L1_2 = 100
    L0_2(L1_2)
    L0_2 = GetPlayerData
    L0_2 = L0_2()
    PlayerData = L0_2
  end
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3
    function L0_3()
      local L0_4, L1_4
      L0_4 = Config
      L0_4 = L0_4.Framework
      if "esx" == L0_4 then
        L0_4 = PlayerData
        if L0_4 then
          L0_4 = PlayerData
          L0_4 = L0_4.accounts
          if L0_4 then
            L0_4 = PlayerData
            L0_4 = L0_4.job
            if L0_4 then
              L0_4 = PlayerData
              L0_4 = L0_4.firstName
            end
          end
        end
        return L0_4
      else
        L0_4 = Config
        L0_4 = L0_4.Framework
        if "qbx" ~= L0_4 then
          L0_4 = Config
          L0_4 = L0_4.Framework
          if "qb" ~= L0_4 then
            goto lbl_42
          end
        end
        L0_4 = PlayerData
        if L0_4 then
          L0_4 = PlayerData
          L0_4 = L0_4.money
          if L0_4 then
            L0_4 = PlayerData
            L0_4 = L0_4.job
            if L0_4 then
              L0_4 = PlayerData
              L0_4 = L0_4.charinfo
            end
          end
        end
        return L0_4
      end
      ::lbl_42::
      L0_4 = true
      return L0_4
    end
    while true do
      L1_3 = L0_3
      L1_3 = L1_3()
      if L1_3 then
        break
      end
      L1_3 = Wait
      L2_3 = 500
      L1_3(L2_3)
      L1_3 = GetPlayerData
      L1_3 = L1_3()
      PlayerData = L1_3
    end
  end
  L0_2(L1_2)
  L0_2 = AwaitServerCallback
  L1_2 = "prism-hudv2:GetProfilePicture"
  L0_2 = L0_2(L1_2)
  ProfileData = L0_2
  L0_2 = ProfileData
  if L0_2 then
    L0_2 = L0_2.profilePic
  end
  Profile = L0_2
  L0_2 = ToggleHud
  L1_2 = true
  L0_2(L1_2)
  L0_2 = LoadMinimapStyle
  L0_2()
  L0_2 = Config
  L0_2 = L0_2.PlayerInfo
  if not L0_2 then
    L0_2 = {}
  end
  L1_2 = SendNUIMessage
  L2_2 = {}
  L2_2.action = "setPlayerInfoConfig"
  L3_2 = {}
  L4_2 = L0_2.voice
  L4_2 = false ~= L4_2
  L3_2.voice = L4_2
  L4_2 = L0_2.jobTime
  L4_2 = false ~= L4_2
  L3_2.jobTime = L4_2
  L4_2 = L0_2.bankCash
  L4_2 = false ~= L4_2
  L3_2.bankCash = L4_2
  L4_2 = L0_2.playerId
  L4_2 = false ~= L4_2
  L3_2.playerId = L4_2
  L4_2 = L0_2.radio
  L4_2 = false ~= L4_2
  L3_2.radio = L4_2
  L4_2 = L0_2.weapon
  L4_2 = false ~= L4_2
  L3_2.weapon = L4_2
  L2_2.data = L3_2
  L1_2(L2_2)
  L1_2 = Config
  L1_2 = L1_2.ServerLogo
  if L1_2 then
    L1_2 = Config
    L1_2 = L1_2.ServerLogo
    L1_2 = L1_2.enabled
    if L1_2 then
      L1_2 = SendNUIMessage
      L2_2 = {}
      L2_2.action = "setServerLogo"
      L3_2 = {}
      L3_2.enabled = true
      L4_2 = Config
      L4_2 = L4_2.ServerLogo
      L4_2 = L4_2.width
      if not L4_2 then
        L4_2 = 120
      end
      L3_2.width = L4_2
      L4_2 = Config
      L4_2 = L4_2.ServerLogo
      L4_2 = L4_2.height
      if not L4_2 then
        L4_2 = 120
      end
      L3_2.height = L4_2
      L2_2.data = L3_2
      L1_2(L2_2)
    end
  end
  L1_2 = Config
  L1_2 = L1_2.CustomStats
  if L1_2 then
    L1_2 = Config
    L1_2 = L1_2.CustomStats
    L1_2 = #L1_2
    if L1_2 > 0 then
      L1_2 = SendNUIMessage
      L2_2 = {}
      L2_2.action = "registerCustomStats"
      L3_2 = Config
      L3_2 = L3_2.CustomStats
      L2_2.data = L3_2
      L1_2(L2_2)
    end
  end
  L1_2 = Config
  L1_2 = L1_2.CustomInfoFields
  if L1_2 then
    L1_2 = Config
    L1_2 = L1_2.CustomInfoFields
    L1_2 = #L1_2
    if L1_2 > 0 then
      L1_2 = SendNUIMessage
      L2_2 = {}
      L2_2.action = "registerCustomInfoFields"
      L3_2 = Config
      L3_2 = L3_2.CustomInfoFields
      L2_2.data = L3_2
      L1_2(L2_2)
    end
  end
  L1_2 = InitThread
  L1_2()
  L1_2 = Config
  L1_2 = L1_2.Seatbelt
  if L1_2 then
    L1_2 = Config
    L1_2 = L1_2.Seatbelt
    L1_2 = L1_2.Enable
    if L1_2 then
      L1_2 = Seatbelt
      L1_2 = L1_2.Thread
      L1_2()
    end
  end
  L1_2 = BoatHorn
  L1_2 = L1_2.Thread
  L1_2()
  L1_2 = AircraftStall
  L1_2 = L1_2.Thread
  L1_2()
  L1_2 = BicycleBell
  L1_2 = L1_2.Thread
  L1_2()
end
InitHud = L4_1
