local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1
L0_1 = RegisterNetEvent
L1_1 = "prism-hudv2:client:OnPlayerLoaded"
function L2_1()
  local L0_2, L1_2
  L0_2 = InitHud
  L0_2()
end
L0_1(L1_1, L2_1)
L0_1 = AddEventHandler
L1_1 = "onResourceStart"
function L2_1(A0_2)
  local L1_2
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  if A0_2 == L1_2 then
    L1_2 = InitHud
    L1_2()
  end
end
L0_1(L1_1, L2_1)
L0_1 = AddEventHandler
L1_1 = "esx:setPlayerData"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2
  L3_2 = PlayerData
  L3_2[A0_2] = A1_2
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "QBCore:Player:SetPlayerData"
function L2_1(A0_2)
  local L1_2
  PlayerData = A0_2
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "hud:client:UpdateNeeds"
function L2_1(A0_2, A1_2)
  Hunger = A0_2
  Thirst = A1_2
end
L0_1(L1_1, L2_1)
L0_1 = AddStateBagChangeHandler
L1_1 = "hunger"
L2_1 = "player:%s"
L3_1 = L2_1
L2_1 = L2_1.format
L4_1 = ServerId
L2_1 = L2_1(L3_1, L4_1)
function L3_1(A0_2, A1_2, A2_2)
  Hunger = A2_2
end
L0_1(L1_1, L2_1, L3_1)
L0_1 = AddStateBagChangeHandler
L1_1 = "thirst"
L2_1 = "player:%s"
L3_1 = L2_1
L2_1 = L2_1.format
L4_1 = ServerId
L2_1 = L2_1(L3_1, L4_1)
function L3_1(A0_2, A1_2, A2_2)
  Thirst = A2_2
end
L0_1(L1_1, L2_1, L3_1)
L0_1 = AddStateBagChangeHandler
L1_1 = "stress"
L2_1 = "player:%s"
L3_1 = L2_1
L2_1 = L2_1.format
L4_1 = ServerId
L2_1 = L2_1(L3_1, L4_1)
function L3_1(A0_2, A1_2, A2_2)
  local L3_2
  L3_2 = A2_2 or nil
  if not A2_2 then
    L3_2 = 0
  end
  Stress = L3_2
end
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterNetEvent
L1_1 = "hud:client:UpdateStress"
function L2_1(A0_2)
  local L1_2
  Stress = A0_2
end
L0_1(L1_1, L2_1)
L0_1 = AddEventHandler
L1_1 = "esx_status:onTick"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = 1
  L2_2 = #A0_2
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = A0_2[L4_2]
    L5_2 = L5_2.name
    if "thirst" == L5_2 then
      L5_2 = math
      L5_2 = L5_2.floor
      L6_2 = A0_2[L4_2]
      L6_2 = L6_2.percent
      L5_2 = L5_2(L6_2)
      Thirst = L5_2
    end
    L5_2 = A0_2[L4_2]
    L5_2 = L5_2.name
    if "hunger" == L5_2 then
      L5_2 = math
      L5_2 = L5_2.floor
      L6_2 = A0_2[L4_2]
      L6_2 = L6_2.percent
      L5_2 = L5_2(L6_2)
      Hunger = L5_2
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = Config
L0_1 = L0_1.CustomStats
if L0_1 then
  L0_1 = ipairs
  L1_1 = Config
  L1_1 = L1_1.CustomStats
  L0_1, L1_1, L2_1, L3_1 = L0_1(L1_1)
  for L4_1, L5_1 in L0_1, L1_1, L2_1, L3_1 do
    L6_1 = L5_1.stateBag
    if L6_1 then
      L6_1 = L5_1.stateBag
      if "" ~= L6_1 then
        L6_1 = AddStateBagChangeHandler
        L7_1 = L5_1.stateBag
        L8_1 = "player:%s"
        L9_1 = L8_1
        L8_1 = L8_1.format
        L10_1 = ServerId
        L8_1 = L8_1(L9_1, L10_1)
        function L9_1(A0_2, A1_2, A2_2)
          local L3_2, L4_2, L5_2, L6_2
          if nil ~= A2_2 then
            L3_2 = CustomStatValues
            L4_2 = L5_1.id
            L5_2 = tonumber
            L6_2 = A2_2
            L5_2 = L5_2(L6_2)
            if not L5_2 then
              L5_2 = 0
            end
            L3_2[L4_2] = L5_2
          end
        end
        L6_1(L7_1, L8_1, L9_1)
      end
    end
  end
end
L0_1 = Config
L0_1 = L0_1.CustomInfoFields
if L0_1 then
  L0_1 = ipairs
  L1_1 = Config
  L1_1 = L1_1.CustomInfoFields
  L0_1, L1_1, L2_1, L3_1 = L0_1(L1_1)
  for L4_1, L5_1 in L0_1, L1_1, L2_1, L3_1 do
    L6_1 = L5_1.stateBag
    if L6_1 then
      L6_1 = L5_1.stateBag
      if "" ~= L6_1 then
        L6_1 = AddStateBagChangeHandler
        L7_1 = L5_1.stateBag
        L8_1 = "player:%s"
        L9_1 = L8_1
        L8_1 = L8_1.format
        L10_1 = ServerId
        L8_1 = L8_1(L9_1, L10_1)
        function L9_1(A0_2, A1_2, A2_2)
          local L3_2, L4_2, L5_2, L6_2
          if nil ~= A2_2 then
            L3_2 = CustomInfoValues
            L4_2 = L5_1.id
            L5_2 = tostring
            L6_2 = A2_2
            L5_2 = L5_2(L6_2)
            L3_2[L4_2] = L5_2
          end
        end
        L6_1(L7_1, L8_1, L9_1)
      end
    end
  end
end
