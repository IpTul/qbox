local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1
UiReady = nil
IsHudUiHidden = false
L0_1 = GetPlayerData
L0_1 = L0_1()
PlayerData = L0_1
L0_1 = GetPlayerServerId
L1_1 = PlayerId
L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1 = L1_1()
L0_1 = L0_1(L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1)
ServerId = L0_1
Oxygen = 0
Hunger = 75
Thirst = 75
Stress = 0
Street = "Unknown"
ZoneName = ""
Profile = ""
CurrentSpeedLimit = 0
InSpeedZone = false
L0_1 = {}
CustomStatValues = L0_1
L0_1 = Config
L0_1 = L0_1.CustomStats
if L0_1 then
  L0_1 = ipairs
  L1_1 = Config
  L1_1 = L1_1.CustomStats
  L0_1, L1_1, L2_1, L3_1 = L0_1(L1_1)
  for L4_1, L5_1 in L0_1, L1_1, L2_1, L3_1 do
    L6_1 = CustomStatValues
    L7_1 = L5_1.id
    L8_1 = L5_1.defaultValue
    if not L8_1 then
      L8_1 = 0
    end
    L6_1[L7_1] = L8_1
  end
end
L0_1 = {}
CustomInfoValues = L0_1
L0_1 = Config
L0_1 = L0_1.CustomInfoFields
if L0_1 then
  L0_1 = ipairs
  L1_1 = Config
  L1_1 = L1_1.CustomInfoFields
  L0_1, L1_1, L2_1, L3_1 = L0_1(L1_1)
  for L4_1, L5_1 in L0_1, L1_1, L2_1, L3_1 do
    L6_1 = CustomInfoValues
    L7_1 = L5_1.id
    L8_1 = L5_1.defaultValue
    if not L8_1 then
      L8_1 = ""
    end
    L6_1[L7_1] = L8_1
  end
end
function L0_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  if not (A0_2 and A1_2) or "" == A1_2 then
    L2_2 = nil
    return L2_2
  end
  L2_2 = A0_2
  L3_2 = string
  L3_2 = L3_2.gmatch
  L4_2 = A1_2
  L5_2 = "[^%.]+"
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2, L5_2)
  for L7_2 in L3_2, L4_2, L5_2, L6_2 do
    L8_2 = type
    L9_2 = L2_2
    L8_2 = L8_2(L9_2)
    if "table" ~= L8_2 then
      L8_2 = nil
      return L8_2
    end
    L2_2 = L2_2[L7_2]
    if nil == L2_2 then
      L8_2 = nil
      return L8_2
    end
  end
  return L2_2
end
L1_1 = {}
L2_1 = 2725352035
L1_1[L2_1] = "WEAPON_UNARMED"
L2_1 = 453432689
L1_1[L2_1] = "WEAPON_PISTOL"
L2_1 = 3219281620
L1_1[L2_1] = "WEAPON_COMBATPISTOL"
L2_1 = 1593441988
L1_1[L2_1] = "WEAPON_APPISTOL"
L2_1 = 584646201
L1_1[L2_1] = "WEAPON_PISTOL50"
L2_1 = 2578377531
L1_1[L2_1] = "WEAPON_SNSPISTOL"
L2_1 = 3218215474
L1_1[L2_1] = "WEAPON_HEAVYPISTOL"
L2_1 = 137902532
L1_1[L2_1] = "WEAPON_VINTAGEPISTOL"
L2_1 = 1198879012
L1_1[L2_1] = "WEAPON_MARKSMANPISTOL"
L2_1 = 3696079510
L1_1[L2_1] = "WEAPON_MACHINEPISTOL"
L2_1 = 3523564046
L1_1[L2_1] = "WEAPON_REVOLVER"
L2_1 = 3415619887
L1_1[L2_1] = "WEAPON_REVOLVER_MK2"
L2_1 = 1853742572
L1_1[L2_1] = "WEAPON_DOUBLEACTION"
L2_1 = 2548703416
L1_1[L2_1] = "WEAPON_PISTOL_MK2"
L2_1 = 2285322324
L1_1[L2_1] = "WEAPON_SNSPISTOL_MK2"
L2_1 = 2441047180
L1_1[L2_1] = "WEAPON_NAVYREVOLVER"
L2_1 = 2823098547
L1_1[L2_1] = "WEAPON_CERAMICPISTOL"
L2_1 = 1470379660
L1_1[L2_1] = "WEAPON_STUNGUN_MP"
L2_1 = 2939590305
L1_1[L2_1] = "WEAPON_FLAREGUN"
L2_1 = 2054101426
L1_1[L2_1] = "WEAPON_PISTOLXM3"
L2_1 = 727643628
L1_1[L2_1] = "WEAPON_RAYPISTOL"
L2_1 = 1470379660
L1_1[L2_1] = "WEAPON_GADGETPISTOL"
L2_1 = 324215364
L1_1[L2_1] = "WEAPON_MICROSMG"
L2_1 = 736523883
L1_1[L2_1] = "WEAPON_SMG"
L2_1 = 2024373456
L1_1[L2_1] = "WEAPON_SMG_MK2"
L2_1 = 4024951519
L1_1[L2_1] = "WEAPON_ASSAULTSMG"
L2_1 = 171789620
L1_1[L2_1] = "WEAPON_COMBATPDW"
L2_1 = 3675956304
L1_1[L2_1] = "WEAPON_MINISMG"
L2_1 = 998675967
L1_1[L2_1] = "WEAPON_TECPISTOL"
L2_1 = 3173288789
L1_1[L2_1] = "WEAPON_PUMPSHOTGUN"
L2_1 = 487013001
L1_1[L2_1] = "WEAPON_PUMPSHOTGUN_MK2"
L2_1 = 2017895192
L1_1[L2_1] = "WEAPON_SAWNOFFSHOTGUN"
L2_1 = 3800352039
L1_1[L2_1] = "WEAPON_ASSAULTSHOTGUN"
L2_1 = 2640438543
L1_1[L2_1] = "WEAPON_BULLPUPSHOTGUN"
L2_1 = 984333226
L1_1[L2_1] = "WEAPON_HEAVYSHOTGUN"
L2_1 = 317205821
L1_1[L2_1] = "WEAPON_DBSHOTGUN"
L2_1 = 317205821
L1_1[L2_1] = "WEAPON_AUTOSHOTGUN"
L2_1 = 94989220
L1_1[L2_1] = "WEAPON_COMBATSHOTGUN"
L2_1 = 3220176749
L1_1[L2_1] = "WEAPON_ASSAULTRIFLE"
L2_1 = 961495388
L1_1[L2_1] = "WEAPON_ASSAULTRIFLE_MK2"
L2_1 = 2210333304
L1_1[L2_1] = "WEAPON_CARBINERIFLE"
L2_1 = 4208062921
L1_1[L2_1] = "WEAPON_CARBINERIFLE_MK2"
L2_1 = 2937143193
L1_1[L2_1] = "WEAPON_ADVANCEDRIFLE"
L2_1 = 3231910285
L1_1[L2_1] = "WEAPON_SPECIALCARBINE"
L2_1 = 2526821735
L1_1[L2_1] = "WEAPON_SPECIALCARBINE_MK2"
L2_1 = 2132975508
L1_1[L2_1] = "WEAPON_BULLPUPRIFLE"
L2_1 = 2228681469
L1_1[L2_1] = "WEAPON_BULLPUPRIFLE_MK2"
L2_1 = 1649403952
L1_1[L2_1] = "WEAPON_COMPACTRIFLE"
L2_1 = 3347935668
L1_1[L2_1] = "WEAPON_HEAVYRIFLE"
L2_1 = 2636060646
L1_1[L2_1] = "WEAPON_MILITARYRIFLE"
L2_1 = 3520460075
L1_1[L2_1] = "WEAPON_TACTICALRIFLE"
L2_1 = 103710331
L1_1[L2_1] = "WEAPON_BATTLERIFLE"
L2_1 = 2634544996
L1_1[L2_1] = "WEAPON_GUSENBERG"
L2_1 = 1627465347
L1_1[L2_1] = "WEAPON_MG"
L2_1 = 2144741730
L1_1[L2_1] = "WEAPON_COMBATMG"
L2_1 = 3686625920
L1_1[L2_1] = "WEAPON_COMBATMG_MK2"
L2_1 = 1198256469
L1_1[L2_1] = "WEAPON_RAYCARBINE"
L2_1 = 100416529
L1_1[L2_1] = "WEAPON_SNIPERRIFLE"
L2_1 = 205991906
L1_1[L2_1] = "WEAPON_HEAVYSNIPER"
L2_1 = 177293209
L1_1[L2_1] = "WEAPON_HEAVYSNIPER_MK2"
L2_1 = 3342088282
L1_1[L2_1] = "WEAPON_MARKSMANRIFLE"
L2_1 = 1785463520
L1_1[L2_1] = "WEAPON_MARKSMANRIFLE_MK2"
L2_1 = 1853742572
L1_1[L2_1] = "WEAPON_PRECISIONRIFLE"
L2_1 = 2828843422
L1_1[L2_1] = "WEAPON_MUSKET"
L2_1 = 2982836145
L1_1[L2_1] = "WEAPON_RPG"
L2_1 = 2694266206
L1_1[L2_1] = "WEAPON_GRENADELAUNCHER"
L2_1 = 1672152130
L1_1[L2_1] = "WEAPON_GRENADELAUNCHER_SMOKE"
L2_1 = 1119849093
L1_1[L2_1] = "WEAPON_MINIGUN"
L2_1 = 2138347493
L1_1[L2_1] = "WEAPON_FIREWORK"
L2_1 = 1834241177
L1_1[L2_1] = "WEAPON_RAILGUN"
L2_1 = 1672152130
L1_1[L2_1] = "WEAPON_HOMINGLAUNCHER"
L2_1 = 125959754
L1_1[L2_1] = "WEAPON_COMPACTLAUNCHER"
L2_1 = 3056410471
L1_1[L2_1] = "WEAPON_RAYMINIGUN"
L2_1 = 3676729658
L1_1[L2_1] = "WEAPON_EMPLAUNCHER"
L2_1 = 189566327
L1_1[L2_1] = "WEAPON_RAILGUNXM3"
L2_1 = 500554837
L1_1[L2_1] = "WEAPON_SNOWLAUNCHER"
L2_1 = 2481070269
L1_1[L2_1] = "WEAPON_GRENADE"
L2_1 = 741814745
L1_1[L2_1] = "WEAPON_BZGAS"
L2_1 = 615608432
L1_1[L2_1] = "WEAPON_MOLOTOV"
L2_1 = 741814745
L1_1[L2_1] = "WEAPON_STICKYBOMB"
L2_1 = 2874559379
L1_1[L2_1] = "WEAPON_PROXMINE"
L2_1 = 126349499
L1_1[L2_1] = "WEAPON_SNOWBALL"
L2_1 = 3125143736
L1_1[L2_1] = "WEAPON_PIPEBOMB"
L2_1 = 600439132
L1_1[L2_1] = "WEAPON_BALL"
L2_1 = 4256991824
L1_1[L2_1] = "WEAPON_SMOKEGRENADE"
L2_1 = 1233104067
L1_1[L2_1] = "WEAPON_FLARE"
L2_1 = 4159824478
L1_1[L2_1] = "WEAPON_ACIDPACKAGE"
L2_1 = 2578778090
L1_1[L2_1] = "WEAPON_KNIFE"
L2_1 = 1737195953
L1_1[L2_1] = "WEAPON_NIGHTSTICK"
L2_1 = 1317494643
L1_1[L2_1] = "WEAPON_HAMMER"
L2_1 = 2508868239
L1_1[L2_1] = "WEAPON_BAT"
L2_1 = 1141786504
L1_1[L2_1] = "WEAPON_GOLFCLUB"
L2_1 = 2227010557
L1_1[L2_1] = "WEAPON_CROWBAR"
L2_1 = 4192643659
L1_1[L2_1] = "WEAPON_BOTTLE"
L2_1 = 2460120199
L1_1[L2_1] = "WEAPON_DAGGER"
L2_1 = 4191993645
L1_1[L2_1] = "WEAPON_HATCHET"
L2_1 = 3638508604
L1_1[L2_1] = "WEAPON_KNUCKLE"
L2_1 = 3713923289
L1_1[L2_1] = "WEAPON_MACHETE"
L2_1 = 2343591895
L1_1[L2_1] = "WEAPON_FLASHLIGHT"
L2_1 = 3756226112
L1_1[L2_1] = "WEAPON_SWITCHBLADE"
L2_1 = 2484171525
L1_1[L2_1] = "WEAPON_POOLCUE"
L2_1 = 419712736
L1_1[L2_1] = "WEAPON_WRENCH"
L2_1 = 3441901897
L1_1[L2_1] = "WEAPON_BATTLEAXE"
L2_1 = 940833800
L1_1[L2_1] = "WEAPON_STONE_HATCHET"
L2_1 = 1703483498
L1_1[L2_1] = "WEAPON_CANDYCANE"
L2_1 = 1011563495
L1_1[L2_1] = "WEAPON_STUNROD"
L2_1 = 883325847
L1_1[L2_1] = "WEAPON_PETROLCAN"
L2_1 = 911657153
L1_1[L2_1] = "WEAPON_STUNGUN"
L2_1 = 101631238
L1_1[L2_1] = "WEAPON_FIREEXTINGUISHER"
L2_1 = 3126027122
L1_1[L2_1] = "WEAPON_HAZARDCAN"
L2_1 = 406929569
L1_1[L2_1] = "WEAPON_FERTILIZERCAN"
L2_1 = 3694157021
L1_1[L2_1] = "WEAPON_HACKINGDEVICE"
L2_1 = 3684886537
L1_1[L2_1] = "WEAPON_METALDETECTOR"
WeaponNames = L1_1
function L1_1(A0_2)
  local L1_2
  if A0_2 < 0 then
    A0_2 = A0_2 & 4294967295
  end
  L1_2 = WeaponNames
  L1_2 = L1_2[A0_2]
  if not L1_2 then
    L1_2 = nil
  end
  return L1_2
end
GetWeaponName = L1_1
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L1_2 = GetCurrentPedWeapon
  L2_2 = A0_2
  L3_2 = true
  L1_2, L2_2 = L1_2(L2_2, L3_2)
  L3_2 = L2_2
  if L2_2 and L2_2 < 0 then
    L3_2 = L2_2 & 4294967295
  end
  if not L1_2 or 2725352035 == L3_2 or 0 == L2_2 then
    L4_2 = ""
    L5_2 = 0
    L6_2 = 0
    return L4_2, L5_2, L6_2
  end
  L4_2 = GetWeaponName
  L5_2 = L2_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    L5_2 = string
    L5_2 = L5_2.format
    L6_2 = "WEAPON_%X"
    L7_2 = L3_2
    L5_2 = L5_2(L6_2, L7_2)
    L4_2 = L5_2
  end
  if "WEAPON_UNARMED" == L4_2 then
    L5_2 = ""
    L6_2 = 0
    L7_2 = 0
    return L5_2, L6_2, L7_2
  end
  L5_2 = 0
  L6_2 = GetAmmoInPedWeapon
  L7_2 = A0_2
  L8_2 = L2_2
  L6_2 = L6_2(L7_2, L8_2)
  L7_2 = GetAmmoInClip
  L8_2 = A0_2
  L9_2 = L2_2
  L7_2, L8_2 = L7_2(L8_2, L9_2)
  L5_2 = L8_2 or L5_2
  if L7_2 and not L8_2 then
    L5_2 = 0
  end
  L9_2 = L4_2
  L10_2 = L5_2
  L11_2 = L6_2
  return L9_2, L10_2, L11_2
end
GetWeaponData = L1_1
function L1_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = nil
  L2_2 = HudSettings
  L2_2 = L2_2.compassFollowsCamera
  if L2_2 then
    L2_2 = GetGameplayCamRot
    L3_2 = 2
    L2_2 = L2_2(L3_2)
    L1_2 = L2_2.z
  else
    L2_2 = GetEntityHeading
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    L1_2 = L2_2
  end
  L2_2 = 360.0
  L2_2 = L2_2 - L1_2
  L2_2 = L2_2 % 360.0
  return L2_2
end
GetCompassHeading = L1_1
function L1_1()
  local L0_2, L1_2, L2_2
  L0_2 = Config
  L0_2 = L0_2.Framework
  if "qbx" ~= L0_2 then
    L0_2 = Config
    L0_2 = L0_2.Framework
    if "qb" ~= L0_2 then
      goto lbl_34
    end
  end
  L0_2 = PlayerData
  if L0_2 then
    L0_2 = PlayerData
    L0_2 = L0_2.charinfo
    if L0_2 then
      goto lbl_18
    end
  end
  L0_2 = ""
  do return L0_2 end
  ::lbl_18::
  L0_2 = PlayerData
  L0_2 = L0_2.charinfo
  L0_2 = L0_2.firstname
  if not L0_2 then
    L0_2 = ""
  end
  L1_2 = " "
  L2_2 = PlayerData
  L2_2 = L2_2.charinfo
  L2_2 = L2_2.lastname
  if not L2_2 then
    L2_2 = ""
  end
  L0_2 = L0_2 .. L1_2 .. L2_2
  do return L0_2 end
  goto lbl_56
  ::lbl_34::
  L0_2 = Config
  L0_2 = L0_2.Framework
  if "esx" == L0_2 then
    L0_2 = PlayerData
    if not L0_2 then
      L0_2 = ""
      return L0_2
    end
    L0_2 = PlayerData
    L0_2 = L0_2.firstName
    if not L0_2 then
      L0_2 = ""
    end
    L1_2 = " "
    L2_2 = PlayerData
    L2_2 = L2_2.lastName
    if not L2_2 then
      L2_2 = ""
    end
    L0_2 = L0_2 .. L1_2 .. L2_2
    return L0_2
  end
  ::lbl_56::
  L0_2 = ""
  return L0_2
end
GetCharName = L1_1
L1_1 = _ENV
L2_1 = "GetCardinalDirection"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = {}
  L2_2 = "N"
  L3_2 = "NE"
  L4_2 = "E"
  L5_2 = "SE"
  L6_2 = "S"
  L7_2 = "SW"
  L8_2 = "W"
  L9_2 = "NW"
  L10_2 = "N"
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L1_2[3] = L4_2
  L1_2[4] = L5_2
  L1_2[5] = L6_2
  L1_2[6] = L7_2
  L1_2[7] = L8_2
  L1_2[8] = L9_2
  L1_2[9] = L10_2
  L2_2 = math
  L2_2 = L2_2.floor
  L3_2 = A0_2 + 22.5
  L3_2 = L3_2 / 45.0
  L2_2 = L2_2(L3_2)
  L2_2 = L2_2 + 1
  L3_2 = L1_2[L2_2]
  return L3_2
end
L1_1[L2_1] = L3_1
L1_1 = _ENV
L2_1 = "RegisterCommand"
L1_1 = L1_1[L2_1]
L2_1 = _ENV
L3_1 = "Config"
L2_1 = L2_1[L3_1]
L3_1 = "HudSettings"
L2_1 = L2_1[L3_1]
L3_1 = "command"
L2_1 = L2_1[L3_1]
function L3_1()
  local L0_2, L1_2
  L0_2 = ToggleHudSettingsMenu
  L1_2 = true
  L0_2(L1_2)
end
L4_1 = false
L1_1(L2_1, L3_1, L4_1)
L1_1 = _ENV
L2_1 = "Config"
L1_1 = L1_1[L2_1]
L2_1 = "HudSettings"
L1_1 = L1_1[L2_1]
L2_1 = "keyBind"
L1_1 = L1_1[L2_1]
if L1_1 then
  L1_1 = _ENV
  L2_1 = "RegisterKeyMapping"
  L1_1 = L1_1[L2_1]
  L2_1 = _ENV
  L3_1 = "Config"
  L2_1 = L2_1[L3_1]
  L3_1 = "HudSettings"
  L2_1 = L2_1[L3_1]
  L3_1 = "command"
  L2_1 = L2_1[L3_1]
  L3_1 = "Open HUD Settings Menu"
  L4_1 = "keyboard"
  L5_1 = _ENV
  L6_1 = "Config"
  L5_1 = L5_1[L6_1]
  L6_1 = "HudSettings"
  L5_1 = L5_1[L6_1]
  L6_1 = "keyBind"
  L5_1 = L5_1[L6_1]
  L1_1(L2_1, L3_1, L4_1, L5_1)
end
L1_1 = _ENV
L2_1 = "Config"
L1_1 = L1_1[L2_1]
L2_1 = "VehicleControl"
L1_1 = L1_1[L2_1]
L2_1 = "enable"
L1_1 = L1_1[L2_1]
if L1_1 then
  L1_1 = _ENV
  L2_1 = "RegisterCommand"
  L1_1 = L1_1[L2_1]
  L2_1 = _ENV
  L3_1 = "Config"
  L2_1 = L2_1[L3_1]
  L3_1 = "VehicleControl"
  L2_1 = L2_1[L3_1]
  L3_1 = "command"
  L2_1 = L2_1[L3_1]
  function L3_1()
    local L0_2, L1_2
    L0_2 = ToggleVehicleControl
    L0_2()
  end
  L4_1 = false
  L1_1(L2_1, L3_1, L4_1)
  L1_1 = _ENV
  L2_1 = "Config"
  L1_1 = L1_1[L2_1]
  L2_1 = "VehicleControl"
  L1_1 = L1_1[L2_1]
  L2_1 = "keyBind"
  L1_1 = L1_1[L2_1]
  if L1_1 then
    L1_1 = _ENV
    L2_1 = "RegisterKeyMapping"
    L1_1 = L1_1[L2_1]
    L2_1 = _ENV
    L3_1 = "Config"
    L2_1 = L2_1[L3_1]
    L3_1 = "VehicleControl"
    L2_1 = L2_1[L3_1]
    L3_1 = "command"
    L2_1 = L2_1[L3_1]
    L3_1 = "Toggle Vehicle Control Menu"
    L4_1 = "keyboard"
    L5_1 = _ENV
    L6_1 = "Config"
    L5_1 = L5_1[L6_1]
    L6_1 = "VehicleControl"
    L5_1 = L5_1[L6_1]
    L6_1 = "keyBind"
    L5_1 = L5_1[L6_1]
    L1_1(L2_1, L3_1, L4_1, L5_1)
  end
end
L1_1 = _ENV
L2_1 = "Config"
L1_1 = L1_1[L2_1]
L2_1 = "VehicleKeybinds"
L1_1 = L1_1[L2_1]
if L1_1 then
  L1_1 = _ENV
  L2_1 = "Config"
  L1_1 = L1_1[L2_1]
  L2_1 = "VehicleKeybinds"
  L1_1 = L1_1[L2_1]
  L2_1 = "indicatorLeft"
  L1_1 = L1_1[L2_1]
  if L1_1 then
    L1_1 = _ENV
    L2_1 = "Config"
    L1_1 = L1_1[L2_1]
    L2_1 = "VehicleKeybinds"
    L1_1 = L1_1[L2_1]
    L2_1 = "indicatorLeft"
    L1_1 = L1_1[L2_1]
    L2_1 = "enable"
    L1_1 = L1_1[L2_1]
    if L1_1 then
      L1_1 = _ENV
      L2_1 = "RegisterCommand"
      L1_1 = L1_1[L2_1]
      L2_1 = _ENV
      L3_1 = "Config"
      L2_1 = L2_1[L3_1]
      L3_1 = "VehicleKeybinds"
      L2_1 = L2_1[L3_1]
      L3_1 = "indicatorLeft"
      L2_1 = L2_1[L3_1]
      L3_1 = "command"
      L2_1 = L2_1[L3_1]
      function L3_1()
        local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
        L0_2 = PlayerPedId
        L0_2 = L0_2()
        L1_2 = GetVehiclePedIsIn
        L2_2 = L0_2
        L3_2 = false
        L1_2 = L1_2(L2_2, L3_2)
        if 0 ~= L1_2 then
          L2_2 = GetPedInVehicleSeat
          L3_2 = L1_2
          L4_2 = -1
          L2_2 = L2_2(L3_2, L4_2)
          if L2_2 == L0_2 then
            L2_2 = VehicleControlState
            L3_2 = VehicleControlState
            L3_2 = L3_2.indicatorLeft
            L3_2 = not L3_2
            L2_2.indicatorLeft = L3_2
            L2_2 = VehicleControlState
            L2_2.indicatorRight = false
            L2_2 = VehicleControlState
            L2_2.hazard = false
            L2_2 = SetVehicleIndicatorLights
            L3_2 = L1_2
            L4_2 = 1
            L5_2 = VehicleControlState
            L5_2 = L5_2.indicatorLeft
            L2_2(L3_2, L4_2, L5_2)
            L2_2 = SetVehicleIndicatorLights
            L3_2 = L1_2
            L4_2 = 0
            L5_2 = false
            L2_2(L3_2, L4_2, L5_2)
          end
        end
      end
      L4_1 = false
      L1_1(L2_1, L3_1, L4_1)
      L1_1 = _ENV
      L2_1 = "Config"
      L1_1 = L1_1[L2_1]
      L2_1 = "VehicleKeybinds"
      L1_1 = L1_1[L2_1]
      L2_1 = "indicatorLeft"
      L1_1 = L1_1[L2_1]
      L2_1 = "keyBind"
      L1_1 = L1_1[L2_1]
      if L1_1 then
        L1_1 = _ENV
        L2_1 = "RegisterKeyMapping"
        L1_1 = L1_1[L2_1]
        L2_1 = _ENV
        L3_1 = "Config"
        L2_1 = L2_1[L3_1]
        L3_1 = "VehicleKeybinds"
        L2_1 = L2_1[L3_1]
        L3_1 = "indicatorLeft"
        L2_1 = L2_1[L3_1]
        L3_1 = "command"
        L2_1 = L2_1[L3_1]
        L3_1 = "Left Indicator"
        L4_1 = "keyboard"
        L5_1 = _ENV
        L6_1 = "Config"
        L5_1 = L5_1[L6_1]
        L6_1 = "VehicleKeybinds"
        L5_1 = L5_1[L6_1]
        L6_1 = "indicatorLeft"
        L5_1 = L5_1[L6_1]
        L6_1 = "keyBind"
        L5_1 = L5_1[L6_1]
        L1_1(L2_1, L3_1, L4_1, L5_1)
      end
    end
  end
  L1_1 = _ENV
  L2_1 = "Config"
  L1_1 = L1_1[L2_1]
  L2_1 = "VehicleKeybinds"
  L1_1 = L1_1[L2_1]
  L2_1 = "indicatorRight"
  L1_1 = L1_1[L2_1]
  if L1_1 then
    L1_1 = _ENV
    L2_1 = "Config"
    L1_1 = L1_1[L2_1]
    L2_1 = "VehicleKeybinds"
    L1_1 = L1_1[L2_1]
    L2_1 = "indicatorRight"
    L1_1 = L1_1[L2_1]
    L2_1 = "enable"
    L1_1 = L1_1[L2_1]
    if L1_1 then
      L1_1 = _ENV
      L2_1 = "RegisterCommand"
      L1_1 = L1_1[L2_1]
      L2_1 = _ENV
      L3_1 = "Config"
      L2_1 = L2_1[L3_1]
      L3_1 = "VehicleKeybinds"
      L2_1 = L2_1[L3_1]
      L3_1 = "indicatorRight"
      L2_1 = L2_1[L3_1]
      L3_1 = "command"
      L2_1 = L2_1[L3_1]
      function L3_1()
        local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
        L0_2 = PlayerPedId
        L0_2 = L0_2()
        L1_2 = GetVehiclePedIsIn
        L2_2 = L0_2
        L3_2 = false
        L1_2 = L1_2(L2_2, L3_2)
        if 0 ~= L1_2 then
          L2_2 = GetPedInVehicleSeat
          L3_2 = L1_2
          L4_2 = -1
          L2_2 = L2_2(L3_2, L4_2)
          if L2_2 == L0_2 then
            L2_2 = VehicleControlState
            L3_2 = VehicleControlState
            L3_2 = L3_2.indicatorRight
            L3_2 = not L3_2
            L2_2.indicatorRight = L3_2
            L2_2 = VehicleControlState
            L2_2.indicatorLeft = false
            L2_2 = VehicleControlState
            L2_2.hazard = false
            L2_2 = SetVehicleIndicatorLights
            L3_2 = L1_2
            L4_2 = 0
            L5_2 = VehicleControlState
            L5_2 = L5_2.indicatorRight
            L2_2(L3_2, L4_2, L5_2)
            L2_2 = SetVehicleIndicatorLights
            L3_2 = L1_2
            L4_2 = 1
            L5_2 = false
            L2_2(L3_2, L4_2, L5_2)
          end
        end
      end
      L4_1 = false
      L1_1(L2_1, L3_1, L4_1)
      L1_1 = _ENV
      L2_1 = "Config"
      L1_1 = L1_1[L2_1]
      L2_1 = "VehicleKeybinds"
      L1_1 = L1_1[L2_1]
      L2_1 = "indicatorRight"
      L1_1 = L1_1[L2_1]
      L2_1 = "keyBind"
      L1_1 = L1_1[L2_1]
      if L1_1 then
        L1_1 = _ENV
        L2_1 = "RegisterKeyMapping"
        L1_1 = L1_1[L2_1]
        L2_1 = _ENV
        L3_1 = "Config"
        L2_1 = L2_1[L3_1]
        L3_1 = "VehicleKeybinds"
        L2_1 = L2_1[L3_1]
        L3_1 = "indicatorRight"
        L2_1 = L2_1[L3_1]
        L3_1 = "command"
        L2_1 = L2_1[L3_1]
        L3_1 = "Right Indicator"
        L4_1 = "keyboard"
        L5_1 = _ENV
        L6_1 = "Config"
        L5_1 = L5_1[L6_1]
        L6_1 = "VehicleKeybinds"
        L5_1 = L5_1[L6_1]
        L6_1 = "indicatorRight"
        L5_1 = L5_1[L6_1]
        L6_1 = "keyBind"
        L5_1 = L5_1[L6_1]
        L1_1(L2_1, L3_1, L4_1, L5_1)
      end
    end
  end
  L1_1 = _ENV
  L2_1 = "Config"
  L1_1 = L1_1[L2_1]
  L2_1 = "VehicleKeybinds"
  L1_1 = L1_1[L2_1]
  L2_1 = "hazard"
  L1_1 = L1_1[L2_1]
  if L1_1 then
    L1_1 = _ENV
    L2_1 = "Config"
    L1_1 = L1_1[L2_1]
    L2_1 = "VehicleKeybinds"
    L1_1 = L1_1[L2_1]
    L2_1 = "hazard"
    L1_1 = L1_1[L2_1]
    L2_1 = "enable"
    L1_1 = L1_1[L2_1]
    if L1_1 then
      L1_1 = _ENV
      L2_1 = "RegisterCommand"
      L1_1 = L1_1[L2_1]
      L2_1 = _ENV
      L3_1 = "Config"
      L2_1 = L2_1[L3_1]
      L3_1 = "VehicleKeybinds"
      L2_1 = L2_1[L3_1]
      L3_1 = "hazard"
      L2_1 = L2_1[L3_1]
      L3_1 = "command"
      L2_1 = L2_1[L3_1]
      function L3_1()
        local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
        L0_2 = PlayerPedId
        L0_2 = L0_2()
        L1_2 = GetVehiclePedIsIn
        L2_2 = L0_2
        L3_2 = false
        L1_2 = L1_2(L2_2, L3_2)
        if 0 ~= L1_2 then
          L2_2 = GetPedInVehicleSeat
          L3_2 = L1_2
          L4_2 = -1
          L2_2 = L2_2(L3_2, L4_2)
          if L2_2 == L0_2 then
            L2_2 = VehicleControlState
            L3_2 = VehicleControlState
            L3_2 = L3_2.hazard
            L3_2 = not L3_2
            L2_2.hazard = L3_2
            L2_2 = VehicleControlState
            L2_2.indicatorLeft = false
            L2_2 = VehicleControlState
            L2_2.indicatorRight = false
            L2_2 = SetVehicleIndicatorLights
            L3_2 = L1_2
            L4_2 = 0
            L5_2 = VehicleControlState
            L5_2 = L5_2.hazard
            L2_2(L3_2, L4_2, L5_2)
            L2_2 = SetVehicleIndicatorLights
            L3_2 = L1_2
            L4_2 = 1
            L5_2 = VehicleControlState
            L5_2 = L5_2.hazard
            L2_2(L3_2, L4_2, L5_2)
          end
        end
      end
      L4_1 = false
      L1_1(L2_1, L3_1, L4_1)
      L1_1 = _ENV
      L2_1 = "Config"
      L1_1 = L1_1[L2_1]
      L2_1 = "VehicleKeybinds"
      L1_1 = L1_1[L2_1]
      L2_1 = "hazard"
      L1_1 = L1_1[L2_1]
      L2_1 = "keyBind"
      L1_1 = L1_1[L2_1]
      if L1_1 then
        L1_1 = _ENV
        L2_1 = "RegisterKeyMapping"
        L1_1 = L1_1[L2_1]
        L2_1 = _ENV
        L3_1 = "Config"
        L2_1 = L2_1[L3_1]
        L3_1 = "VehicleKeybinds"
        L2_1 = L2_1[L3_1]
        L3_1 = "hazard"
        L2_1 = L2_1[L3_1]
        L3_1 = "command"
        L2_1 = L2_1[L3_1]
        L3_1 = "Hazard Lights"
        L4_1 = "keyboard"
        L5_1 = _ENV
        L6_1 = "Config"
        L5_1 = L5_1[L6_1]
        L6_1 = "VehicleKeybinds"
        L5_1 = L5_1[L6_1]
        L6_1 = "hazard"
        L5_1 = L5_1[L6_1]
        L6_1 = "keyBind"
        L5_1 = L5_1[L6_1]
        L1_1(L2_1, L3_1, L4_1, L5_1)
      end
    end
  end
  L1_1 = _ENV
  L2_1 = "Config"
  L1_1 = L1_1[L2_1]
  L2_1 = "VehicleKeybinds"
  L1_1 = L1_1[L2_1]
  L2_1 = "cruiseControl"
  L1_1 = L1_1[L2_1]
  if L1_1 then
    L1_1 = _ENV
    L2_1 = "Config"
    L1_1 = L1_1[L2_1]
    L2_1 = "VehicleKeybinds"
    L1_1 = L1_1[L2_1]
    L2_1 = "cruiseControl"
    L1_1 = L1_1[L2_1]
    L2_1 = "enable"
    L1_1 = L1_1[L2_1]
    if L1_1 then
      L1_1 = _ENV
      L2_1 = "RegisterCommand"
      L1_1 = L1_1[L2_1]
      L2_1 = _ENV
      L3_1 = "Config"
      L2_1 = L2_1[L3_1]
      L3_1 = "VehicleKeybinds"
      L2_1 = L2_1[L3_1]
      L3_1 = "cruiseControl"
      L2_1 = L2_1[L3_1]
      L3_1 = "command"
      L2_1 = L2_1[L3_1]
      function L3_1()
        local L0_2, L1_2, L2_2, L3_2, L4_2
        L0_2 = PlayerPedId
        L0_2 = L0_2()
        L1_2 = GetVehiclePedIsIn
        L2_2 = L0_2
        L3_2 = false
        L1_2 = L1_2(L2_2, L3_2)
        if 0 ~= L1_2 then
          L2_2 = GetPedInVehicleSeat
          L3_2 = L1_2
          L4_2 = -1
          L2_2 = L2_2(L3_2, L4_2)
          if L2_2 == L0_2 then
            L2_2 = ToggleCruiseControl
            L2_2()
          end
        end
      end
      L4_1 = false
      L1_1(L2_1, L3_1, L4_1)
      L1_1 = _ENV
      L2_1 = "Config"
      L1_1 = L1_1[L2_1]
      L2_1 = "VehicleKeybinds"
      L1_1 = L1_1[L2_1]
      L2_1 = "cruiseControl"
      L1_1 = L1_1[L2_1]
      L2_1 = "keyBind"
      L1_1 = L1_1[L2_1]
      if L1_1 then
        L1_1 = _ENV
        L2_1 = "RegisterKeyMapping"
        L1_1 = L1_1[L2_1]
        L2_1 = _ENV
        L3_1 = "Config"
        L2_1 = L2_1[L3_1]
        L3_1 = "VehicleKeybinds"
        L2_1 = L2_1[L3_1]
        L3_1 = "cruiseControl"
        L2_1 = L2_1[L3_1]
        L3_1 = "command"
        L2_1 = L2_1[L3_1]
        L3_1 = "Cruise Control"
        L4_1 = "keyboard"
        L5_1 = _ENV
        L6_1 = "Config"
        L5_1 = L5_1[L6_1]
        L6_1 = "VehicleKeybinds"
        L5_1 = L5_1[L6_1]
        L6_1 = "cruiseControl"
        L5_1 = L5_1[L6_1]
        L6_1 = "keyBind"
        L5_1 = L5_1[L6_1]
        L1_1(L2_1, L3_1, L4_1, L5_1)
      end
    end
  end
  L1_1 = _ENV
  L2_1 = "Config"
  L1_1 = L1_1[L2_1]
  L2_1 = "VehicleKeybinds"
  L1_1 = L1_1[L2_1]
  L2_1 = "seatbelt"
  L1_1 = L1_1[L2_1]
  if L1_1 then
    L1_1 = _ENV
    L2_1 = "Config"
    L1_1 = L1_1[L2_1]
    L2_1 = "VehicleKeybinds"
    L1_1 = L1_1[L2_1]
    L2_1 = "seatbelt"
    L1_1 = L1_1[L2_1]
    L2_1 = "enable"
    L1_1 = L1_1[L2_1]
    if L1_1 then
      L1_1 = _ENV
      L2_1 = "RegisterCommand"
      L1_1 = L1_1[L2_1]
      L2_1 = _ENV
      L3_1 = "Config"
      L2_1 = L2_1[L3_1]
      L3_1 = "VehicleKeybinds"
      L2_1 = L2_1[L3_1]
      L3_1 = "seatbelt"
      L2_1 = L2_1[L3_1]
      L3_1 = "command"
      L2_1 = L2_1[L3_1]
      function L3_1()
        local L0_2, L1_2, L2_2, L3_2
        L0_2 = PlayerPedId
        L0_2 = L0_2()
        L1_2 = GetVehiclePedIsIn
        L2_2 = L0_2
        L3_2 = false
        L1_2 = L1_2(L2_2, L3_2)
        if 0 ~= L1_2 then
          L2_2 = ToggleSeatbelt
          L2_2()
        end
      end
      L4_1 = false
      L1_1(L2_1, L3_1, L4_1)
      L1_1 = _ENV
      L2_1 = "Config"
      L1_1 = L1_1[L2_1]
      L2_1 = "VehicleKeybinds"
      L1_1 = L1_1[L2_1]
      L2_1 = "seatbelt"
      L1_1 = L1_1[L2_1]
      L2_1 = "keyBind"
      L1_1 = L1_1[L2_1]
      if L1_1 then
        L1_1 = _ENV
        L2_1 = "RegisterKeyMapping"
        L1_1 = L1_1[L2_1]
        L2_1 = _ENV
        L3_1 = "Config"
        L2_1 = L2_1[L3_1]
        L3_1 = "VehicleKeybinds"
        L2_1 = L2_1[L3_1]
        L3_1 = "seatbelt"
        L2_1 = L2_1[L3_1]
        L3_1 = "command"
        L2_1 = L2_1[L3_1]
        L3_1 = "Toggle Seatbelt"
        L4_1 = "keyboard"
        L5_1 = _ENV
        L6_1 = "Config"
        L5_1 = L5_1[L6_1]
        L6_1 = "VehicleKeybinds"
        L5_1 = L5_1[L6_1]
        L6_1 = "seatbelt"
        L5_1 = L5_1[L6_1]
        L6_1 = "keyBind"
        L5_1 = L5_1[L6_1]
        L1_1(L2_1, L3_1, L4_1, L5_1)
      end
    end
  end
end
L1_1 = _ENV
L2_1 = "CreateThread"
L1_1 = L1_1[L2_1]
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  while true do
    L0_2 = pcall
    L1_2 = GetStreetNames
    L0_2, L1_2, L2_2 = L0_2(L1_2)
    if L0_2 then
      Street = L1_2
      L3_2 = L2_2 or L3_2
      if not L2_2 then
        L3_2 = ""
      end
      ZoneName = L3_2
    end
    L3_2 = Wait
    L4_2 = 3000
    L3_2(L4_2)
  end
end
L1_1(L2_1)
L1_1 = _ENV
L2_1 = "InitThread"
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = false
  L1_2 = ""
  L2_2 = nil
  L3_2 = 0
  L4_2 = 5000
  L5_2 = CreateThread
  function L6_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3
    while true do
      L0_3 = 1000
      L1_3 = {}
      L2_3 = IsHudUiHidden
      if not L2_3 then
        L2_3 = MakeHudHidden
        L2_3 = L2_3()
      end
      if L2_3 then
        L3_3 = L0_2
        if L3_3 then
          L3_3 = HideHud
          L3_3()
          L3_3 = false
          L0_2 = L3_3
        end
      end
      if not L2_3 then
        L3_3 = L0_2
        if not L3_3 then
          L3_3 = ShowHud
          L3_3()
          L3_3 = true
          L0_2 = L3_3
        end
        L3_3 = GetHudUpdateInterval
        L3_3 = L3_3()
        L0_3 = L3_3
        L3_3 = PlayerPedId
        L3_3 = L3_3()
        L4_3 = PlayerId
        L4_3 = L4_3()
        L5_3 = GetVehiclePedIsIn
        L6_3 = L3_3
        L7_3 = false
        L5_3 = L5_3(L6_3, L7_3)
        L6_3 = IsEntityInWater
        L7_3 = L3_3
        L6_3 = L6_3(L7_3)
        L7_3 = LocalPlayer
        L7_3 = L7_3.state
        L7_3 = L7_3.proximity
        if L7_3 then
          L7_3 = LocalPlayer
          L7_3 = L7_3.state
          L7_3 = L7_3.proximity
          L7_3 = L7_3.distance
          if L7_3 then
            goto lbl_53
          end
        end
        L7_3 = 0
        ::lbl_53::
        L8_3 = GetVoiceLevel
        L9_3 = L7_3
        L8_3 = L8_3(L9_3)
        L9_3 = IsPedInAnyVehicle
        L10_3 = L3_3
        L11_3 = false
        L9_3 = 0 ~= L5_3 and L9_3
        L10_3 = NetworkIsPlayerTalking
        L11_3 = L4_3
        L10_3 = L10_3(L11_3)
        L11_3 = nil
        L12_3 = LocalPlayer
        L12_3 = L12_3.state
        L12_3 = L12_3.radioChannel
        L13_3 = false
        L14_3 = HudSettings
        L14_3 = L14_3.showMinimapOnFoot
        if L14_3 then
          L14_3 = DisplayRadar
          L15_3 = true
          L14_3(L15_3)
        else
          L14_3 = DisplayRadar
          L15_3 = L9_3
          L14_3(L15_3)
          L13_3 = not L9_3
        end
        L14_3 = SetBlipAlpha
        L15_3 = GetNorthRadarBlip
        L15_3 = L15_3()
        L16_3 = HudSettings
        L16_3 = L16_3.showNorthBlip
        if L16_3 then
          L16_3 = 255
          if L16_3 then
            goto lbl_96
          end
        end
        L16_3 = 0
        ::lbl_96::
        L14_3(L15_3, L16_3)
        if L6_3 then
          L14_3 = GetPlayerUnderwaterTimeRemaining
          L15_3 = L4_3
          L14_3 = L14_3(L15_3)
          L14_3 = L14_3 * 10
          Oxygen = L14_3
        else
          L14_3 = GetPlayerSprintStaminaRemaining
          L15_3 = L4_3
          L14_3 = L14_3(L15_3)
          L15_3 = 100
          L14_3 = L15_3 - L14_3
          Oxygen = L14_3
        end
        if L9_3 then
          L14_3 = GetVehicleType
          L15_3 = L5_3
          L14_3 = L14_3(L15_3)
          L11_3 = L14_3
        end
        L14_3 = GetGameTimer
        L14_3 = L14_3()
        L15_3 = L3_2
        L15_3 = L14_3 - L15_3
        L16_3 = L4_2
        if L15_3 > L16_3 then
          L3_2 = L14_3
          L15_3 = GetCharName
          L15_3 = L15_3()
          L1_2 = L15_3
          L15_3 = GetPlayerJobAndLabel
          L15_3 = L15_3()
          L2_2 = L15_3
        end
        L15_3 = GetMoney
        L16_3 = PlayerData
        L15_3 = L15_3(L16_3)
        L16_3 = GetBank
        L17_3 = PlayerData
        L16_3 = L16_3(L17_3)
        L17_3 = GetEntityHealth
        L18_3 = L3_3
        L17_3 = L17_3(L18_3)
        L17_3 = L17_3 - 100
        L1_3.health = L17_3
        L17_3 = GetPedArmour
        L18_3 = L3_3
        L17_3 = L17_3(L18_3)
        L1_3.armour = L17_3
        L17_3 = Hunger
        L1_3.hunger = L17_3
        L17_3 = Thirst
        L1_3.thirst = L17_3
        L17_3 = Oxygen
        L1_3.stamina = L17_3
        L17_3 = Oxygen
        L1_3.oxygen = L17_3
        L17_3 = Stress
        L1_3.stress = L17_3
        L17_3 = Config
        L17_3 = L17_3.Stress
        L17_3 = not L17_3
        L1_3.stressEnabled = L17_3
        L1_3.voice = L8_3
        L1_3.isInVehicle = L9_3
        L1_3.isUnderWater = L6_3
        L1_3.cash = L15_3
        L1_3.bank = L16_3
        L17_3 = GetCompassHeading
        L18_3 = L3_3
        L17_3 = L17_3(L18_3)
        L1_3.compassHeading = L17_3
        L17_3 = GetCardinalDirection
        L18_3 = L1_3.compassHeading
        L17_3 = L17_3(L18_3)
        L1_3.direction = L17_3
        L17_3 = ServerId
        L1_3.ServerId = L17_3
        L17_3 = Street
        L1_3.Street = L17_3
        L17_3 = ZoneName
        L1_3.ZoneName = L17_3
        L17_3 = GetGameTimeInHHMM
        L17_3, L18_3 = L17_3()
        L1_3.period = L18_3
        L1_3.time = L17_3
        L1_3.talking = L10_3
        L1_3.vehicleType = L11_3
        L17_3 = L1_2
        L1_3.PlayerName = L17_3
        L17_3 = L2_2
        L1_3.job = L17_3
        L17_3 = Profile
        L1_3.image = L17_3
        L17_3 = CurrentSpeedLimit
        L1_3.SpeedLimit = L17_3
        L17_3 = InSpeedZone
        L1_3.inSpeedZone = L17_3
        L1_3.radioChannel = L12_3
        if L9_3 then
          L17_3 = GetEntitySpeed
          L18_3 = L5_3
          L17_3 = L17_3(L18_3)
          L18_3 = HudSettings
          L18_3 = L18_3.speedUnit
          if "kmh" == L18_3 then
            L18_3 = 3.6
            if L18_3 then
              goto lbl_221
            end
          end
          L18_3 = 2.236936
          ::lbl_221::
          L19_3 = math
          L19_3 = L19_3.ceil
          L20_3 = L17_3 * L18_3
          L19_3 = L19_3(L20_3)
          L1_3.Speed = L19_3
          L19_3 = GetVehicleCurrentGear
          L20_3 = L5_3
          L19_3 = L19_3(L20_3)
          L1_3.Gear = L19_3
          L19_3 = math
          L19_3 = L19_3.floor
          L20_3 = GetVehicleEngineHealth
          L21_3 = L5_3
          L20_3 = L20_3(L21_3)
          L20_3 = L20_3 / 10
          L19_3 = L19_3(L20_3)
          L1_3.Engine = L19_3
          L19_3 = GetVehicleCurrentRpm
          L20_3 = L5_3
          L19_3 = L19_3(L20_3)
          L1_3.Rpm = L19_3
          L19_3 = math
          L19_3 = L19_3.floor
          L20_3 = GetVehicleFuel
          L21_3 = L5_3
          L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3 = L20_3(L21_3)
          L19_3 = L19_3(L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3)
          L1_3.Fuel = L19_3
          L19_3 = GetWeaponData
          L20_3 = L3_3
          L19_3, L20_3, L21_3 = L19_3(L20_3)
          L1_3.currentWeapon = L19_3
          L1_3.ammoInClip = L20_3
          L1_3.ammoTotal = L21_3
          L22_3 = VehicleControlState
          L22_3 = L22_3.indicatorLeft
          if not L22_3 then
            L22_3 = false
          end
          L1_3.indicatorLeft = L22_3
          L22_3 = VehicleControlState
          L22_3 = L22_3.indicatorRight
          if not L22_3 then
            L22_3 = false
          end
          L1_3.indicatorRight = L22_3
          L22_3 = VehicleControlState
          L22_3 = L22_3.hazard
          if not L22_3 then
            L22_3 = false
          end
          L1_3.hazard = L22_3
          L22_3 = GetVehicleLightsState
          L23_3 = L5_3
          L22_3, L23_3, L24_3 = L22_3(L23_3)
          L25_3 = L23_3 or L25_3
          if not L23_3 then
            L25_3 = L24_3
          end
          L1_3.headlights = L25_3
          L25_3 = Seatbelt
          L25_3 = L25_3.enabled
          if not L25_3 then
            L25_3 = false
          end
          L1_3.seatbelt = L25_3
          L25_3 = CruiseControl
          L25_3 = L25_3.enabled
          if not L25_3 then
            L25_3 = false
          end
          L1_3.cruise = L25_3
          L25_3 = GetVehicleDoorLockStatus
          L26_3 = L5_3
          L25_3 = L25_3(L26_3)
          L25_3 = 2 == L25_3
          L1_3.locked = L25_3
          if "boat" == L11_3 then
            L25_3 = GetEntityHeading
            L26_3 = L5_3
            L25_3 = L25_3(L26_3)
            L26_3 = 360.0
            L25_3 = L26_3 - L25_3
            L25_3 = L25_3 % 360.0
            L1_3.boatHeading = L25_3
            L25_3 = GetEntityPitch
            L26_3 = L5_3
            L25_3 = L25_3(L26_3)
            L1_3.boatTrim = L25_3
          else
            L1_3.boatHeading = 0
            L1_3.boatTrim = 0
          end
          if "heli" == L11_3 or "plane" == L11_3 then
            L25_3 = GetEntityCoords
            L26_3 = L5_3
            L25_3 = L25_3(L26_3)
            L26_3 = 0
            L27_3 = GetGroundZFor_3dCoord
            L28_3 = L25_3.x
            L29_3 = L25_3.y
            L30_3 = L25_3.z
            L31_3 = false
            L27_3, L28_3 = L27_3(L28_3, L29_3, L30_3, L31_3)
            if L27_3 then
              L26_3 = L28_3
            end
            L29_3 = math
            L29_3 = L29_3.floor
            L30_3 = L25_3.z
            L30_3 = L30_3 - L26_3
            L29_3 = L29_3(L30_3)
            L1_3.altitude = L29_3
            L29_3 = GetEntityPitch
            L30_3 = L5_3
            L29_3 = L29_3(L30_3)
            L1_3.pitch = L29_3
            L29_3 = GetEntityRoll
            L30_3 = L5_3
            L29_3 = L29_3(L30_3)
            L1_3.roll = L29_3
            L29_3 = GetEntityVelocity
            L30_3 = L5_3
            L29_3 = L29_3(L30_3)
            L30_3 = L29_3.z
            L30_3 = L30_3 * 60
            L1_3.verticalSpeed = L30_3
            if "plane" == L11_3 then
              L30_3 = 30.0
              if L30_3 then
                goto lbl_365
              end
            end
            L30_3 = 0
            ::lbl_365::
            L31_3 = "plane" == L11_3 and L17_3 < L30_3
            L1_3.isStalling = L31_3
          else
            L1_3.altitude = 0
            L1_3.pitch = 0
            L1_3.roll = 0
            L1_3.verticalSpeed = 0
            L1_3.isStalling = false
          end
          if "bicycle" == L11_3 then
            L25_3 = math
            L25_3 = L25_3.floor
            L26_3 = L17_3 * 8
            L25_3 = L25_3(L26_3)
            L1_3.cadence = L25_3
            L25_3 = 72
            L26_3 = math
            L26_3 = L26_3.min
            L27_3 = L17_3 * 3
            L28_3 = 120
            L26_3 = L26_3(L27_3, L28_3)
            L27_3 = math
            L27_3 = L27_3.floor
            L28_3 = L25_3 + L26_3
            L27_3 = L27_3(L28_3)
            L1_3.heartRate = L27_3
          else
            L1_3.cadence = 0
            L1_3.heartRate = 72
          end
        else
          L1_3.Speed = 0
          L1_3.Gear = 0
          L1_3.Engine = 100
          L1_3.Rpm = 0
          L1_3.Fuel = 100
          L17_3 = GetWeaponData
          L18_3 = L3_3
          L17_3, L18_3, L19_3 = L17_3(L18_3)
          L1_3.currentWeapon = L17_3
          L1_3.ammoInClip = L18_3
          L1_3.ammoTotal = L19_3
          L1_3.indicatorLeft = false
          L1_3.indicatorRight = false
          L1_3.hazard = false
          L1_3.headlights = false
          L1_3.seatbelt = false
          L1_3.cruise = false
          L1_3.locked = false
          L1_3.boatHeading = 0
          L1_3.boatTrim = 0
          L1_3.altitude = 0
          L1_3.pitch = 0
          L1_3.roll = 0
          L1_3.verticalSpeed = 0
          L1_3.isStalling = false
          L1_3.cadence = 0
          L1_3.heartRate = 72
        end
        L1_3.minimapHidden = L13_3
        L17_3 = Config
        L17_3 = L17_3.CustomStats
        if L17_3 then
          L17_3 = Config
          L17_3 = L17_3.CustomStats
          L17_3 = #L17_3
          if L17_3 > 0 then
            L17_3 = CustomStatValues
            L1_3.customStats = L17_3
          end
        end
        L17_3 = Config
        L17_3 = L17_3.CustomInfoFields
        if L17_3 then
          L17_3 = Config
          L17_3 = L17_3.CustomInfoFields
          L17_3 = #L17_3
          if L17_3 > 0 then
            L17_3 = ipairs
            L18_3 = Config
            L18_3 = L18_3.CustomInfoFields
            L17_3, L18_3, L19_3, L20_3 = L17_3(L18_3)
            for L21_3, L22_3 in L17_3, L18_3, L19_3, L20_3 do
              L23_3 = L22_3.dataPath
              if L23_3 then
                L23_3 = L22_3.dataPath
                if "" ~= L23_3 then
                  L23_3 = PlayerData
                  if L23_3 then
                    L23_3 = L0_1
                    L24_3 = PlayerData
                    L25_3 = L22_3.dataPath
                    L23_3 = L23_3(L24_3, L25_3)
                    if nil ~= L23_3 then
                      L24_3 = CustomInfoValues
                      L25_3 = L22_3.id
                      L26_3 = tostring
                      L27_3 = L23_3
                      L26_3 = L26_3(L27_3)
                      L24_3[L25_3] = L26_3
                    end
                  end
                end
              end
            end
            L17_3 = CustomInfoValues
            L1_3.customInfoFields = L17_3
          end
        end
        L17_3 = SendHudData
        L18_3 = L1_3
        L17_3(L18_3)
      end
      L3_3 = Wait
      L4_3 = L0_3
      L3_3(L4_3)
    end
  end
  L5_2(L6_2)
end
L1_1[L2_1] = L3_1
L1_1 = _ENV
L2_1 = "CreateThread"
L1_1 = L1_1[L2_1]
function L2_1()
  local L0_2, L1_2, L2_2, L3_2
  while true do
    L0_2 = SetRadarZoom
    L1_2 = 1000
    L0_2(L1_2)
    L0_2 = DisableControlAction
    L1_2 = 0
    L2_2 = 20
    L3_2 = true
    L0_2(L1_2, L2_2, L3_2)
    L0_2 = Seatbelt
    L0_2 = L0_2.enabled
    if L0_2 then
      L0_2 = DisableControlAction
      L1_2 = 0
      L2_2 = 75
      L3_2 = true
      L0_2(L1_2, L2_2, L3_2)
    end
    L0_2 = Wait
    L1_2 = 0
    L0_2(L1_2)
  end
end
L1_1(L2_1)
L1_1 = _ENV
L2_1 = "CreateThread"
L1_1 = L1_1[L2_1]
function L2_1()
  local L0_2, L1_2, L2_2
  L0_2 = RequestScaleformMovie
  L1_2 = "minimap"
  L0_2 = L0_2(L1_2)
  L1_2 = HasScaleformMovieLoaded
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    L1_2 = RequestScaleformMovie
    L2_2 = L0_2
    L1_2(L2_2)
    while true do
      L1_2 = HasScaleformMovieLoaded
      L2_2 = L0_2
      L1_2 = L1_2(L2_2)
      if L1_2 then
        break
      end
      L1_2 = Wait
      L2_2 = 1
      L1_2(L2_2)
    end
  end
end
L1_1(L2_1)
L1_1 = _ENV
L2_1 = "SetSpeedLimit"
function L3_1(A0_2)
  local L1_2
  L1_2 = A0_2 or nil
  if not A0_2 then
    L1_2 = 0
  end
  CurrentSpeedLimit = L1_2
  L1_2 = A0_2 or L1_2
  L1_2 = A0_2 and A0_2 > 0
  InSpeedZone = L1_2
end
L1_1[L2_1] = L3_1
L1_1 = _ENV
L2_1 = "ClearSpeedLimit"
function L3_1()
  local L0_2, L1_2
  CurrentSpeedLimit = 0
  InSpeedZone = false
end
L1_1[L2_1] = L3_1
L1_1 = _ENV
L2_1 = "exports"
L1_1 = L1_1[L2_1]
L2_1 = "SetSpeedLimit"
L3_1 = _ENV
L4_1 = "SetSpeedLimit"
L3_1 = L3_1[L4_1]
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "exports"
L1_1 = L1_1[L2_1]
L2_1 = "ClearSpeedLimit"
L3_1 = _ENV
L4_1 = "ClearSpeedLimit"
L3_1 = L3_1[L4_1]
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "exports"
L1_1 = L1_1[L2_1]
L2_1 = "GetCurrentSpeedLimit"
function L3_1()
  local L0_2, L1_2
  L0_2 = CurrentSpeedLimit
  return L0_2
end
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "exports"
L1_1 = L1_1[L2_1]
L2_1 = "IsInSpeedZone"
function L3_1()
  local L0_2, L1_2
  L0_2 = InSpeedZone
  return L0_2
end
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "exports"
L1_1 = L1_1[L2_1]
L2_1 = "SetCustomStat"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = type
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  if "string" == L2_2 then
    L2_2 = CustomStatValues
    L2_2 = L2_2[A0_2]
    if nil ~= L2_2 then
      L2_2 = CustomStatValues
      L3_2 = tonumber
      L4_2 = A1_2
      L3_2 = L3_2(L4_2)
      if not L3_2 then
        L3_2 = 0
      end
      L2_2[A0_2] = L3_2
    end
  end
end
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "exports"
L1_1 = L1_1[L2_1]
L2_1 = "GetCustomStat"
function L3_1(A0_2)
  local L1_2, L2_2
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if "string" == L1_2 then
    L1_2 = CustomStatValues
    L1_2 = L1_2[A0_2]
    return L1_2
  end
  L1_2 = nil
  return L1_2
end
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "exports"
L1_1 = L1_1[L2_1]
L2_1 = "UpdatePlayerInfoField"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = type
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  if "string" == L2_2 then
    L2_2 = CustomInfoValues
    L2_2 = L2_2[A0_2]
    if nil ~= L2_2 then
      L2_2 = CustomInfoValues
      L3_2 = tostring
      L4_2 = A1_2 or L4_2
      if not A1_2 then
        L4_2 = ""
      end
      L3_2 = L3_2(L4_2)
      L2_2[A0_2] = L3_2
    end
  end
end
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "exports"
L1_1 = L1_1[L2_1]
L2_1 = "GetPlayerInfoField"
function L3_1(A0_2)
  local L1_2, L2_2
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if "string" == L1_2 then
    L1_2 = CustomInfoValues
    L1_2 = L1_2[A0_2]
    return L1_2
  end
  L1_2 = nil
  return L1_2
end
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "exports"
L1_1 = L1_1[L2_1]
L2_1 = "IsHudUiHidden"
function L3_1()
  local L0_2, L1_2
  L0_2 = IsHudUiHidden
  return L0_2
end
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "exports"
L1_1 = L1_1[L2_1]
L2_1 = "SetHudHidden"
function L3_1(A0_2)
  local L1_2
  IsHudUiHidden = A0_2
end
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "RegisterNetEvent"
L1_1 = L1_1[L2_1]
L2_1 = "prism-hud:setSpeedLimit"
function L3_1(A0_2)
  local L1_2, L2_2
  L1_2 = SetSpeedLimit
  L2_2 = A0_2
  L1_2(L2_2)
end
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "RegisterNetEvent"
L1_1 = L1_1[L2_1]
L2_1 = "prism-hud:clearSpeedLimit"
function L3_1()
  local L0_2, L1_2
  L0_2 = ClearSpeedLimit
  L0_2()
end
L1_1(L2_1, L3_1)
L1_1 = _ENV
L2_1 = "CreateThread"
L1_1 = L1_1[L2_1]
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L0_2 = Config
  L0_2 = L0_2.SpeedLimits
  if L0_2 then
    L0_2 = Config
    L0_2 = L0_2.SpeedLimits
    L0_2 = L0_2.enabled
    if L0_2 then
      goto lbl_11
    end
  end
  do return end
  ::lbl_11::
  while true do
    L0_2 = PlayerPedId
    L0_2 = L0_2()
    L1_2 = GetEntityCoords
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    L2_2 = false
    L3_2 = 0
    L4_2 = ipairs
    L5_2 = Config
    L5_2 = L5_2.SpeedLimits
    L5_2 = L5_2.zones
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
    for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
      L10_2 = L9_2.coords
      L10_2 = L1_2 - L10_2
      L10_2 = #L10_2
      L11_2 = L9_2.radius
      if L10_2 <= L11_2 then
        L2_2 = true
        L11_2 = L9_2.speedLimit
        if L3_2 < L11_2 then
          L3_2 = L9_2.speedLimit
        end
      end
    end
    if L2_2 then
      L4_2 = SetSpeedLimit
      L5_2 = L3_2
      L4_2(L5_2)
    else
      L4_2 = Config
      L4_2 = L4_2.SpeedLimits
      L4_2 = L4_2.defaultLimit
      if L4_2 > 0 then
        L4_2 = SetSpeedLimit
        L5_2 = Config
        L5_2 = L5_2.SpeedLimits
        L5_2 = L5_2.defaultLimit
        L4_2(L5_2)
      else
        L4_2 = ClearSpeedLimit
        L4_2()
      end
    end
    L4_2 = Wait
    L5_2 = Config
    L5_2 = L5_2.SpeedLimits
    L5_2 = L5_2.checkInterval
    if not L5_2 then
      L5_2 = 1000
    end
    L4_2(L5_2)
  end
end
L1_1(L2_1)
