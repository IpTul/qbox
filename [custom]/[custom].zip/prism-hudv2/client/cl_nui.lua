local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = RegisterNUICallback
L1_1 = "uiReady"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2
  UiReady = true
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "closeHudSettings"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = ToggleHudSettingsMenu
  L3_2 = false
  L2_2(L3_2)
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "openEditMode"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  EditModeVisible = true
  L2_2 = SendNUIMessage
  L3_2 = {}
  L3_2.action = "switchToEditMode"
  L4_2 = {}
  L5_2 = Locales
  L4_2.locales = L5_2
  L3_2.data = L4_2
  L2_2(L3_2)
  L2_2 = SetNuiFocus
  L3_2 = true
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "closeEditMode"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = ToggleEditMode
  L3_2 = false
  L2_2(L3_2)
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
MinimapPosition = nil
L0_1 = RegisterNUICallback
L1_1 = "saveMinimapPosition"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2
  if A0_2 then
    L2_2 = A0_2.x
    if L2_2 then
      L2_2 = A0_2.y
      if L2_2 then
        L2_2 = {}
        L3_2 = A0_2.x
        L2_2.x = L3_2
        L3_2 = A0_2.y
        L2_2.y = L3_2
        L3_2 = A0_2.scale
        if not L3_2 then
          L3_2 = 1
        end
        L2_2.scale = L3_2
        MinimapPosition = L2_2
        L2_2 = LoadMinimapStyle
        L2_2()
      end
    end
  end
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "closeVehicleControl"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = ToggleVehicleControl
  L3_2 = false
  L2_2(L3_2)
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "vehicleAction"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = GetVehiclePedIsIn
  L4_2 = L2_2
  L5_2 = false
  L3_2 = L3_2(L4_2, L5_2)
  if 0 == L3_2 then
    L4_2 = A1_2
    L5_2 = {}
    L5_2.success = false
    L5_2.error = "Not in vehicle"
    L4_2(L5_2)
    return
  end
  L4_2 = A0_2.action
  L5_2 = A0_2.index
  if "engine" == L4_2 then
    L6_2 = GetIsVehicleEngineRunning
    L7_2 = L3_2
    L6_2 = L6_2(L7_2)
    L7_2 = SetVehicleEngineOn
    L8_2 = L3_2
    L9_2 = not L6_2
    L10_2 = false
    L11_2 = true
    L7_2(L8_2, L9_2, L10_2, L11_2)
    L7_2 = A1_2
    L8_2 = {}
    L8_2.success = true
    L9_2 = not L6_2
    L8_2.state = L9_2
    L7_2(L8_2)
  elseif "lock" == L4_2 then
    L6_2 = GetVehicleDoorLockStatus
    L7_2 = L3_2
    L6_2 = L6_2(L7_2)
    if 2 == L6_2 then
      L7_2 = 1
      if L7_2 then
        goto lbl_48
      end
    end
    L7_2 = 2
    ::lbl_48::
    L8_2 = SetVehicleDoorsLocked
    L9_2 = L3_2
    L10_2 = L7_2
    L8_2(L9_2, L10_2)
    L8_2 = A1_2
    L9_2 = {}
    L9_2.success = true
    L10_2 = 2 == L7_2
    L9_2.state = L10_2
    L8_2(L9_2)
  elseif "door" == L4_2 then
    L6_2 = tonumber
    L7_2 = L5_2
    L6_2 = L6_2(L7_2)
    if not L6_2 then
      L6_2 = 0
    end
    L7_2 = GetVehicleDoorAngleRatio
    L8_2 = L3_2
    L9_2 = L6_2
    L7_2 = L7_2(L8_2, L9_2)
    if L7_2 > 0.0 then
      L8_2 = SetVehicleDoorShut
      L9_2 = L3_2
      L10_2 = L6_2
      L11_2 = false
      L8_2(L9_2, L10_2, L11_2)
      L8_2 = A1_2
      L9_2 = {}
      L9_2.success = true
      L9_2.state = false
      L8_2(L9_2)
    else
      L8_2 = SetVehicleDoorOpen
      L9_2 = L3_2
      L10_2 = L6_2
      L11_2 = false
      L12_2 = false
      L8_2(L9_2, L10_2, L11_2, L12_2)
      L8_2 = A1_2
      L9_2 = {}
      L9_2.success = true
      L9_2.state = true
      L8_2(L9_2)
    end
  elseif "window" == L4_2 then
    L6_2 = tonumber
    L7_2 = L5_2
    L6_2 = L6_2(L7_2)
    if not L6_2 then
      L6_2 = 0
    end
    L7_2 = tostring
    L8_2 = L6_2
    L7_2 = L7_2(L8_2)
    L8_2 = VehicleControlState
    L8_2 = L8_2.windows
    L8_2 = L8_2[L7_2]
    if not L8_2 then
      L8_2 = false
    end
    if L8_2 then
      L9_2 = RollUpWindow
      L10_2 = L3_2
      L11_2 = L6_2
      L9_2(L10_2, L11_2)
      L9_2 = VehicleControlState
      L9_2 = L9_2.windows
      L9_2[L7_2] = false
    else
      L9_2 = RollDownWindow
      L10_2 = L3_2
      L11_2 = L6_2
      L9_2(L10_2, L11_2)
      L9_2 = VehicleControlState
      L9_2 = L9_2.windows
      L9_2[L7_2] = true
    end
    L9_2 = A1_2
    L10_2 = {}
    L10_2.success = true
    L11_2 = VehicleControlState
    L11_2 = L11_2.windows
    L11_2 = L11_2[L7_2]
    L10_2.state = L11_2
    L9_2(L10_2)
  elseif "indicatorLeft" == L4_2 then
    L6_2 = VehicleControlState
    L7_2 = VehicleControlState
    L7_2 = L7_2.indicatorLeft
    L7_2 = not L7_2
    L6_2.indicatorLeft = L7_2
    L6_2 = VehicleControlState
    L6_2.indicatorRight = false
    L6_2 = VehicleControlState
    L6_2.hazard = false
    L6_2 = SetVehicleIndicatorLights
    L7_2 = L3_2
    L8_2 = 1
    L9_2 = VehicleControlState
    L9_2 = L9_2.indicatorLeft
    L6_2(L7_2, L8_2, L9_2)
    L6_2 = SetVehicleIndicatorLights
    L7_2 = L3_2
    L8_2 = 0
    L9_2 = false
    L6_2(L7_2, L8_2, L9_2)
    L6_2 = A1_2
    L7_2 = {}
    L7_2.success = true
    L8_2 = VehicleControlState
    L8_2 = L8_2.indicatorLeft
    L7_2.state = L8_2
    L6_2(L7_2)
  elseif "indicatorRight" == L4_2 then
    L6_2 = VehicleControlState
    L7_2 = VehicleControlState
    L7_2 = L7_2.indicatorRight
    L7_2 = not L7_2
    L6_2.indicatorRight = L7_2
    L6_2 = VehicleControlState
    L6_2.indicatorLeft = false
    L6_2 = VehicleControlState
    L6_2.hazard = false
    L6_2 = SetVehicleIndicatorLights
    L7_2 = L3_2
    L8_2 = 0
    L9_2 = VehicleControlState
    L9_2 = L9_2.indicatorRight
    L6_2(L7_2, L8_2, L9_2)
    L6_2 = SetVehicleIndicatorLights
    L7_2 = L3_2
    L8_2 = 1
    L9_2 = false
    L6_2(L7_2, L8_2, L9_2)
    L6_2 = A1_2
    L7_2 = {}
    L7_2.success = true
    L8_2 = VehicleControlState
    L8_2 = L8_2.indicatorRight
    L7_2.state = L8_2
    L6_2(L7_2)
  elseif "hazard" == L4_2 then
    L6_2 = VehicleControlState
    L7_2 = VehicleControlState
    L7_2 = L7_2.hazard
    L7_2 = not L7_2
    L6_2.hazard = L7_2
    L6_2 = VehicleControlState
    L6_2.indicatorLeft = false
    L6_2 = VehicleControlState
    L6_2.indicatorRight = false
    L6_2 = SetVehicleIndicatorLights
    L7_2 = L3_2
    L8_2 = 0
    L9_2 = VehicleControlState
    L9_2 = L9_2.hazard
    L6_2(L7_2, L8_2, L9_2)
    L6_2 = SetVehicleIndicatorLights
    L7_2 = L3_2
    L8_2 = 1
    L9_2 = VehicleControlState
    L9_2 = L9_2.hazard
    L6_2(L7_2, L8_2, L9_2)
    L6_2 = A1_2
    L7_2 = {}
    L7_2.success = true
    L8_2 = VehicleControlState
    L8_2 = L8_2.hazard
    L7_2.state = L8_2
    L6_2(L7_2)
  elseif "headlights" == L4_2 then
    L6_2 = VehicleControlState
    L7_2 = VehicleControlState
    L7_2 = L7_2.headlights
    L7_2 = not L7_2
    L6_2.headlights = L7_2
    L6_2 = VehicleControlState
    L6_2 = L6_2.headlights
    if L6_2 then
      L6_2 = SetVehicleLights
      L7_2 = L3_2
      L8_2 = 2
      L6_2(L7_2, L8_2)
    else
      L6_2 = SetVehicleLights
      L7_2 = L3_2
      L8_2 = 1
      L6_2(L7_2, L8_2)
    end
    L6_2 = A1_2
    L7_2 = {}
    L7_2.success = true
    L8_2 = VehicleControlState
    L8_2 = L8_2.headlights
    L7_2.state = L8_2
    L6_2(L7_2)
  elseif "neon" == L4_2 then
    L6_2 = IsVehicleNeonLightEnabled
    L7_2 = L3_2
    L8_2 = 0
    L6_2 = L6_2(L7_2, L8_2)
    L7_2 = 0
    L8_2 = 3
    L9_2 = 1
    for L10_2 = L7_2, L8_2, L9_2 do
      L11_2 = SetVehicleNeonLightEnabled
      L12_2 = L3_2
      L13_2 = L10_2
      L14_2 = not L6_2
      L11_2(L12_2, L13_2, L14_2)
    end
    L7_2 = A1_2
    L8_2 = {}
    L8_2.success = true
    L9_2 = not L6_2
    L8_2.state = L9_2
    L7_2(L8_2)
  elseif "cruise" == L4_2 then
    L6_2 = ToggleCruiseControl
    L6_2 = L6_2()
    L7_2 = A1_2
    L8_2 = {}
    L8_2.success = true
    L8_2.state = L6_2
    L7_2(L8_2)
  elseif "seat" == L4_2 then
    L6_2 = tonumber
    L7_2 = L5_2
    L6_2 = L6_2(L7_2)
    if not L6_2 then
      L6_2 = 0
    end
    L7_2 = L6_2 - 1
    L8_2 = GetPedInVehicleSeat
    L9_2 = L3_2
    L10_2 = L7_2
    L8_2 = L8_2(L9_2, L10_2)
    if 0 == L8_2 or L8_2 == L2_2 then
      L9_2 = TaskWarpPedIntoVehicle
      L10_2 = L2_2
      L11_2 = L3_2
      L12_2 = L7_2
      L9_2(L10_2, L11_2, L12_2)
      L9_2 = A1_2
      L10_2 = {}
      L10_2.success = true
      L9_2(L10_2)
    else
      L9_2 = A1_2
      L10_2 = {}
      L10_2.success = false
      L10_2.error = "Seat occupied"
      L9_2(L10_2)
    end
  else
    L6_2 = A1_2
    L7_2 = {}
    L7_2.success = false
    L7_2.error = "Unknown action"
    L6_2(L7_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "getVehicleState"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = GetVehicleData
  L2_2 = L2_2()
  L3_2 = A1_2
  L4_2 = L2_2 or L4_2
  if not L2_2 then
    L4_2 = {}
  end
  L3_2(L4_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "getDefaultHudSettings"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = A1_2
  L3_2 = Config
  L3_2 = L3_2.DefaultHudSettings
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "getLockedSettings"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = A1_2
  L3_2 = Config
  L3_2 = L3_2.LockedSettings
  if not L3_2 then
    L3_2 = {}
  end
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if "table" ~= L1_2 then
    return A0_2
  end
  L1_2 = {}
  L2_2 = pairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L0_1
    L9_2 = L7_2
    L8_2 = L8_2(L9_2)
    L1_2[L6_2] = L8_2
  end
  return L1_2
end
L1_1 = L0_1
L2_1 = Config
L2_1 = L2_1.DefaultHudSettings
L1_1 = L1_1(L2_1)
HudSettings = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L0_2 = Config
  L0_2 = L0_2.LockedSettings
  if not L0_2 then
    return
  end
  L0_2 = ipairs
  L1_2 = Config
  L1_2 = L1_2.LockedSettings
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = Config
    L6_2 = L6_2.DefaultHudSettings
    L6_2 = L6_2[L5_2]
    if nil ~= L6_2 then
      L6_2 = HudSettings
      L7_2 = L0_1
      L8_2 = Config
      L8_2 = L8_2.DefaultHudSettings
      L8_2 = L8_2[L5_2]
      L7_2 = L7_2(L8_2)
      L6_2[L5_2] = L7_2
    end
  end
end
L2_1 = {}
L2_1.normal = 50
L2_1.balanced = 100
L2_1.performance = 200
function L3_1()
  local L0_2, L1_2
  L0_2 = HudSettings
  L1_2 = L0_2.performanceMode
  L0_2 = L2_1
  L0_2 = L0_2[L1_2]
  if not L0_2 then
    L0_2 = 100
  end
  return L0_2
end
GetHudUpdateInterval = L3_1
L3_1 = RegisterNUICallback
L4_1 = "saveHudSettings"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L2_2 = A0_2.performanceMode
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.performanceMode
    L2_2.performanceMode = L3_2
  end
  L2_2 = A0_2.speedUnit
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.speedUnit
    L2_2.speedUnit = L3_2
  end
  L2_2 = A0_2.distanceUnit
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.distanceUnit
    L2_2.distanceUnit = L3_2
  end
  L2_2 = A0_2.useUltrawide
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L2_2 = L2_2.useUltrawide
    L3_2 = A0_2.useUltrawide
    L2_2 = L2_2 ~= L3_2
    L3_2 = HudSettings
    L4_2 = A0_2.useUltrawide
    L3_2.useUltrawide = L4_2
    if L2_2 then
      L3_2 = LoadMinimapStyle
      L3_2()
    end
  end
  L2_2 = A0_2.showMinimapOnFoot
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.showMinimapOnFoot
    L2_2.showMinimapOnFoot = L3_2
  end
  L2_2 = A0_2.showNorthBlip
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.showNorthBlip
    L2_2.showNorthBlip = L3_2
  end
  L2_2 = A0_2.moveCompassWhenMinimapHidden
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.moveCompassWhenMinimapHidden
    L2_2.moveCompassWhenMinimapHidden = L3_2
  end
  L2_2 = A0_2.minimapStyle
  if L2_2 then
    L2_2 = HudSettings
    L2_2 = L2_2.minimapStyle
    L3_2 = A0_2.minimapStyle
    L2_2 = L2_2 ~= L3_2
    L3_2 = HudSettings
    L4_2 = A0_2.minimapStyle
    L3_2.minimapStyle = L4_2
    if L2_2 then
      L3_2 = LoadMinimapStyle
      L3_2()
    end
  end
  L2_2 = A0_2.showCompassOnFoot
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.showCompassOnFoot
    L2_2.showCompassOnFoot = L3_2
  end
  L2_2 = A0_2.compassFollowsCamera
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.compassFollowsCamera
    L2_2.compassFollowsCamera = L3_2
  end
  L2_2 = A0_2.showNearestPostal
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.showNearestPostal
    L2_2.showNearestPostal = L3_2
  end
  L2_2 = A0_2.locationDisplayBorderRadius
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.locationDisplayBorderRadius
    L2_2.locationDisplayBorderRadius = L3_2
  end
  L2_2 = A0_2.locationDisplayPrimaryColor
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.locationDisplayPrimaryColor
    L2_2.locationDisplayPrimaryColor = L3_2
  end
  L2_2 = A0_2.locationDisplayBackgroundColor
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.locationDisplayBackgroundColor
    L2_2.locationDisplayBackgroundColor = L3_2
  end
  L2_2 = A0_2.locationDisplayTextColor
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.locationDisplayTextColor
    L2_2.locationDisplayTextColor = L3_2
  end
  L2_2 = A0_2.statsStyle
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.statsStyle
    L2_2.statsStyle = L3_2
  end
  L2_2 = A0_2.carBikeSpeedometerStyle
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.carBikeSpeedometerStyle
    L2_2.carBikeSpeedometerStyle = L3_2
  end
  L2_2 = A0_2.carBikeFlashSpeedLimit
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.carBikeFlashSpeedLimit
    L2_2.carBikeFlashSpeedLimit = L3_2
  end
  L2_2 = A0_2.carBikeIndicatorSounds
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.carBikeIndicatorSounds
    L2_2.carBikeIndicatorSounds = L3_2
  end
  L2_2 = A0_2.carBikeSpeedLimitStyle
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.carBikeSpeedLimitStyle
    L2_2.carBikeSpeedLimitStyle = L3_2
  end
  L2_2 = A0_2.carBikeSpeedLimitApproachThreshold
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.carBikeSpeedLimitApproachThreshold
    L2_2.carBikeSpeedLimitApproachThreshold = L3_2
  end
  L2_2 = A0_2.carBikeSeatbeltWarningSound
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.carBikeSeatbeltWarningSound
    L2_2.carBikeSeatbeltWarningSound = L3_2
  end
  L2_2 = A0_2.carBikeSeatbeltSound
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.carBikeSeatbeltSound
    L2_2.carBikeSeatbeltSound = L3_2
  end
  L2_2 = A0_2.statsColors
  if L2_2 then
    L2_2 = {}
    L3_2 = "health"
    L4_2 = "armour"
    L5_2 = "hunger"
    L6_2 = "thirst"
    L7_2 = "stamina"
    L8_2 = "oxygen"
    L9_2 = "stress"
    L2_2[1] = L3_2
    L2_2[2] = L4_2
    L2_2[3] = L5_2
    L2_2[4] = L6_2
    L2_2[5] = L7_2
    L2_2[6] = L8_2
    L2_2[7] = L9_2
    L3_2 = ipairs
    L4_2 = L2_2
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = A0_2.statsColors
      L9_2 = L9_2[L8_2]
      if L9_2 then
        L9_2 = type
        L10_2 = A0_2.statsColors
        L10_2 = L10_2[L8_2]
        L9_2 = L9_2(L10_2)
        if "table" == L9_2 then
          L9_2 = HudSettings
          L9_2 = L9_2.statsColors
          L10_2 = {}
          L11_2 = A0_2.statsColors
          L11_2 = L11_2[L8_2]
          L11_2 = L11_2.progress
          if not L11_2 then
            L11_2 = HudSettings
            L11_2 = L11_2.statsColors
            L11_2 = L11_2[L8_2]
            L11_2 = L11_2.progress
          end
          L10_2.progress = L11_2
          L11_2 = A0_2.statsColors
          L11_2 = L11_2[L8_2]
          L11_2 = L11_2.icon
          if not L11_2 then
            L11_2 = HudSettings
            L11_2 = L11_2.statsColors
            L11_2 = L11_2[L8_2]
            L11_2 = L11_2.icon
          end
          L10_2.icon = L11_2
          L11_2 = A0_2.statsColors
          L11_2 = L11_2[L8_2]
          L11_2 = L11_2.background
          if not L11_2 then
            L11_2 = HudSettings
            L11_2 = L11_2.statsColors
            L11_2 = L11_2[L8_2]
            L11_2 = L11_2.background
          end
          L10_2.background = L11_2
          L9_2[L8_2] = L10_2
        end
      end
    end
  end
  L2_2 = A0_2.customStatsColors
  if L2_2 then
    L2_2 = HudSettings
    L2_2 = L2_2.customStatsColors
    if not L2_2 then
      L2_2 = HudSettings
      L3_2 = {}
      L2_2.customStatsColors = L3_2
    end
    L2_2 = pairs
    L3_2 = A0_2.customStatsColors
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = type
      L9_2 = L7_2
      L8_2 = L8_2(L9_2)
      if "table" == L8_2 then
        L8_2 = HudSettings
        L8_2 = L8_2.customStatsColors
        L9_2 = {}
        L10_2 = L7_2.progress
        if not L10_2 then
          L10_2 = "#FFFFFF"
        end
        L9_2.progress = L10_2
        L10_2 = L7_2.icon
        if not L10_2 then
          L10_2 = "#FFFFFF"
        end
        L9_2.icon = L10_2
        L10_2 = L7_2.background
        if not L10_2 then
          L10_2 = "#FFFFFF"
        end
        L9_2.background = L10_2
        L8_2[L6_2] = L9_2
      end
    end
  end
  L2_2 = A0_2.speedometerColors
  if L2_2 then
    L2_2 = {}
    L3_2 = "style1"
    L4_2 = "style2"
    L5_2 = "style3"
    L6_2 = "style4"
    L7_2 = "style5"
    L8_2 = "style6"
    L2_2[1] = L3_2
    L2_2[2] = L4_2
    L2_2[3] = L5_2
    L2_2[4] = L6_2
    L2_2[5] = L7_2
    L2_2[6] = L8_2
    L3_2 = ipairs
    L4_2 = L2_2
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = A0_2.speedometerColors
      L9_2 = L9_2[L8_2]
      if L9_2 then
        L9_2 = HudSettings
        L9_2 = L9_2.speedometerColors
        L9_2 = L9_2[L8_2]
        if not L9_2 then
          L9_2 = HudSettings
          L9_2 = L9_2.speedometerColors
          L10_2 = {}
          L11_2 = {}
          L10_2.colours = L11_2
          L11_2 = {}
          L10_2.statusColours = L11_2
          L9_2[L8_2] = L10_2
        end
        L9_2 = A0_2.speedometerColors
        L9_2 = L9_2[L8_2]
        L9_2 = L9_2.colours
        if L9_2 then
          L9_2 = pairs
          L10_2 = A0_2.speedometerColors
          L10_2 = L10_2[L8_2]
          L10_2 = L10_2.colours
          L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
          for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
            L15_2 = HudSettings
            L15_2 = L15_2.speedometerColors
            L15_2 = L15_2[L8_2]
            L15_2 = L15_2.colours
            L15_2[L13_2] = L14_2
          end
        end
        L9_2 = A0_2.speedometerColors
        L9_2 = L9_2[L8_2]
        L9_2 = L9_2.statusColours
        if L9_2 then
          L9_2 = pairs
          L10_2 = A0_2.speedometerColors
          L10_2 = L10_2[L8_2]
          L10_2 = L10_2.statusColours
          L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
          for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
            L15_2 = HudSettings
            L15_2 = L15_2.speedometerColors
            L15_2 = L15_2[L8_2]
            L15_2 = L15_2.statusColours
            L15_2[L13_2] = L14_2
          end
        end
      end
    end
  end
  L2_2 = A0_2.bicycleSpeedometerStyle
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.bicycleSpeedometerStyle
    L2_2.bicycleSpeedometerStyle = L3_2
  end
  L2_2 = A0_2.bicycleSpeedometerColors
  if L2_2 then
    L2_2 = {}
    L3_2 = "style1"
    L4_2 = "style2"
    L5_2 = "style3"
    L6_2 = "style4"
    L7_2 = "style5"
    L8_2 = "style6"
    L2_2[1] = L3_2
    L2_2[2] = L4_2
    L2_2[3] = L5_2
    L2_2[4] = L6_2
    L2_2[5] = L7_2
    L2_2[6] = L8_2
    L3_2 = ipairs
    L4_2 = L2_2
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = A0_2.bicycleSpeedometerColors
      L9_2 = L9_2[L8_2]
      if L9_2 then
        L9_2 = HudSettings
        L9_2 = L9_2.bicycleSpeedometerColors
        L9_2 = L9_2[L8_2]
        if not L9_2 then
          L9_2 = HudSettings
          L9_2 = L9_2.bicycleSpeedometerColors
          L10_2 = {}
          L11_2 = {}
          L10_2.colours = L11_2
          L11_2 = {}
          L10_2.statusColours = L11_2
          L9_2[L8_2] = L10_2
        end
        L9_2 = A0_2.bicycleSpeedometerColors
        L9_2 = L9_2[L8_2]
        L9_2 = L9_2.colours
        if L9_2 then
          L9_2 = pairs
          L10_2 = A0_2.bicycleSpeedometerColors
          L10_2 = L10_2[L8_2]
          L10_2 = L10_2.colours
          L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
          for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
            L15_2 = HudSettings
            L15_2 = L15_2.bicycleSpeedometerColors
            L15_2 = L15_2[L8_2]
            L15_2 = L15_2.colours
            L15_2[L13_2] = L14_2
          end
        end
        L9_2 = A0_2.bicycleSpeedometerColors
        L9_2 = L9_2[L8_2]
        L9_2 = L9_2.statusColours
        if L9_2 then
          L9_2 = pairs
          L10_2 = A0_2.bicycleSpeedometerColors
          L10_2 = L10_2[L8_2]
          L10_2 = L10_2.statusColours
          L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
          for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
            L15_2 = HudSettings
            L15_2 = L15_2.bicycleSpeedometerColors
            L15_2 = L15_2[L8_2]
            L15_2 = L15_2.statusColours
            L15_2[L13_2] = L14_2
          end
        end
      end
    end
  end
  L2_2 = A0_2.boatSpeedometerStyle
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.boatSpeedometerStyle
    L2_2.boatSpeedometerStyle = L3_2
  end
  L2_2 = A0_2.boatSpeedometerColors
  if L2_2 then
    L2_2 = {}
    L3_2 = "style1"
    L4_2 = "style2"
    L5_2 = "style3"
    L6_2 = "style4"
    L7_2 = "style5"
    L8_2 = "style6"
    L2_2[1] = L3_2
    L2_2[2] = L4_2
    L2_2[3] = L5_2
    L2_2[4] = L6_2
    L2_2[5] = L7_2
    L2_2[6] = L8_2
    L3_2 = ipairs
    L4_2 = L2_2
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = A0_2.boatSpeedometerColors
      L9_2 = L9_2[L8_2]
      if L9_2 then
        L9_2 = HudSettings
        L9_2 = L9_2.boatSpeedometerColors
        L9_2 = L9_2[L8_2]
        if not L9_2 then
          L9_2 = HudSettings
          L9_2 = L9_2.boatSpeedometerColors
          L10_2 = {}
          L11_2 = {}
          L10_2.colours = L11_2
          L11_2 = {}
          L10_2.statusColours = L11_2
          L9_2[L8_2] = L10_2
        end
        L9_2 = A0_2.boatSpeedometerColors
        L9_2 = L9_2[L8_2]
        L9_2 = L9_2.colours
        if L9_2 then
          L9_2 = pairs
          L10_2 = A0_2.boatSpeedometerColors
          L10_2 = L10_2[L8_2]
          L10_2 = L10_2.colours
          L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
          for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
            L15_2 = HudSettings
            L15_2 = L15_2.boatSpeedometerColors
            L15_2 = L15_2[L8_2]
            L15_2 = L15_2.colours
            L15_2[L13_2] = L14_2
          end
        end
        L9_2 = A0_2.boatSpeedometerColors
        L9_2 = L9_2[L8_2]
        L9_2 = L9_2.statusColours
        if L9_2 then
          L9_2 = pairs
          L10_2 = A0_2.boatSpeedometerColors
          L10_2 = L10_2[L8_2]
          L10_2 = L10_2.statusColours
          L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
          for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
            L15_2 = HudSettings
            L15_2 = L15_2.boatSpeedometerColors
            L15_2 = L15_2[L8_2]
            L15_2 = L15_2.statusColours
            L15_2[L13_2] = L14_2
          end
        end
      end
    end
  end
  L2_2 = A0_2.aircraftSpeedometerStyle
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.aircraftSpeedometerStyle
    L2_2.aircraftSpeedometerStyle = L3_2
  end
  L2_2 = A0_2.aircraftSpeedometerColors
  if L2_2 then
    L2_2 = {}
    L3_2 = "style1"
    L4_2 = "style2"
    L5_2 = "style3"
    L6_2 = "style4"
    L7_2 = "style5"
    L8_2 = "style6"
    L2_2[1] = L3_2
    L2_2[2] = L4_2
    L2_2[3] = L5_2
    L2_2[4] = L6_2
    L2_2[5] = L7_2
    L2_2[6] = L8_2
    L3_2 = ipairs
    L4_2 = L2_2
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = A0_2.aircraftSpeedometerColors
      L9_2 = L9_2[L8_2]
      if L9_2 then
        L9_2 = HudSettings
        L9_2 = L9_2.aircraftSpeedometerColors
        L9_2 = L9_2[L8_2]
        if not L9_2 then
          L9_2 = HudSettings
          L9_2 = L9_2.aircraftSpeedometerColors
          L10_2 = {}
          L11_2 = {}
          L10_2.colours = L11_2
          L11_2 = {}
          L10_2.statusColours = L11_2
          L9_2[L8_2] = L10_2
        end
        L9_2 = A0_2.aircraftSpeedometerColors
        L9_2 = L9_2[L8_2]
        L9_2 = L9_2.colours
        if L9_2 then
          L9_2 = pairs
          L10_2 = A0_2.aircraftSpeedometerColors
          L10_2 = L10_2[L8_2]
          L10_2 = L10_2.colours
          L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
          for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
            L15_2 = HudSettings
            L15_2 = L15_2.aircraftSpeedometerColors
            L15_2 = L15_2[L8_2]
            L15_2 = L15_2.colours
            L15_2[L13_2] = L14_2
          end
        end
        L9_2 = A0_2.aircraftSpeedometerColors
        L9_2 = L9_2[L8_2]
        L9_2 = L9_2.statusColours
        if L9_2 then
          L9_2 = pairs
          L10_2 = A0_2.aircraftSpeedometerColors
          L10_2 = L10_2[L8_2]
          L10_2 = L10_2.statusColours
          L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
          for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
            L15_2 = HudSettings
            L15_2 = L15_2.aircraftSpeedometerColors
            L15_2 = L15_2[L8_2]
            L15_2 = L15_2.statusColours
            L15_2[L13_2] = L14_2
          end
        end
      end
    end
  end
  L2_2 = A0_2.trainSpeedometerStyle
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.trainSpeedometerStyle
    L2_2.trainSpeedometerStyle = L3_2
  end
  L2_2 = A0_2.trainSpeedometerColors
  if L2_2 then
    L2_2 = {}
    L3_2 = "style1"
    L4_2 = "style2"
    L5_2 = "style3"
    L6_2 = "style4"
    L7_2 = "style5"
    L8_2 = "style6"
    L2_2[1] = L3_2
    L2_2[2] = L4_2
    L2_2[3] = L5_2
    L2_2[4] = L6_2
    L2_2[5] = L7_2
    L2_2[6] = L8_2
    L3_2 = ipairs
    L4_2 = L2_2
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = A0_2.trainSpeedometerColors
      L9_2 = L9_2[L8_2]
      if L9_2 then
        L9_2 = HudSettings
        L9_2 = L9_2.trainSpeedometerColors
        L9_2 = L9_2[L8_2]
        if not L9_2 then
          L9_2 = HudSettings
          L9_2 = L9_2.trainSpeedometerColors
          L10_2 = {}
          L11_2 = {}
          L10_2.colours = L11_2
          L11_2 = {}
          L10_2.statusColours = L11_2
          L9_2[L8_2] = L10_2
        end
        L9_2 = A0_2.trainSpeedometerColors
        L9_2 = L9_2[L8_2]
        L9_2 = L9_2.colours
        if L9_2 then
          L9_2 = pairs
          L10_2 = A0_2.trainSpeedometerColors
          L10_2 = L10_2[L8_2]
          L10_2 = L10_2.colours
          L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
          for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
            L15_2 = HudSettings
            L15_2 = L15_2.trainSpeedometerColors
            L15_2 = L15_2[L8_2]
            L15_2 = L15_2.colours
            L15_2[L13_2] = L14_2
          end
        end
        L9_2 = A0_2.trainSpeedometerColors
        L9_2 = L9_2[L8_2]
        L9_2 = L9_2.statusColours
        if L9_2 then
          L9_2 = pairs
          L10_2 = A0_2.trainSpeedometerColors
          L10_2 = L10_2[L8_2]
          L10_2 = L10_2.statusColours
          L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
          for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
            L15_2 = HudSettings
            L15_2 = L15_2.trainSpeedometerColors
            L15_2 = L15_2[L8_2]
            L15_2 = L15_2.statusColours
            L15_2[L13_2] = L14_2
          end
        end
      end
    end
  end
  L2_2 = A0_2.showPlayerAvatar
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.showPlayerAvatar
    L2_2.showPlayerAvatar = L3_2
  end
  L2_2 = A0_2.showRadioChannel
  if nil ~= L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.showRadioChannel
    L2_2.showRadioChannel = L3_2
  end
  L2_2 = A0_2.playerVoiceAlignment
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.playerVoiceAlignment
    L2_2.playerVoiceAlignment = L3_2
  end
  L2_2 = A0_2.playerVoiceBorderRadius
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.playerVoiceBorderRadius
    L2_2.playerVoiceBorderRadius = L3_2
  end
  L2_2 = A0_2.voiceChatActiveColor
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.voiceChatActiveColor
    L2_2.voiceChatActiveColor = L3_2
  end
  L2_2 = A0_2.voiceChatIdleColor
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.voiceChatIdleColor
    L2_2.voiceChatIdleColor = L3_2
  end
  L2_2 = A0_2.playerInfoBorderRadius
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.playerInfoBorderRadius
    L2_2.playerInfoBorderRadius = L3_2
  end
  L2_2 = A0_2.playerInfoBackgroundColor
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.playerInfoBackgroundColor
    L2_2.playerInfoBackgroundColor = L3_2
  end
  L2_2 = A0_2.playerInfoIconColor
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.playerInfoIconColor
    L2_2.playerInfoIconColor = L3_2
  end
  L2_2 = A0_2.playerInfoTextColor
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.playerInfoTextColor
    L2_2.playerInfoTextColor = L3_2
  end
  L2_2 = A0_2.weaponBorderRadius
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.weaponBorderRadius
    L2_2.weaponBorderRadius = L3_2
  end
  L2_2 = A0_2.weaponBackgroundColor
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.weaponBackgroundColor
    L2_2.weaponBackgroundColor = L3_2
  end
  L2_2 = A0_2.weaponIconColor
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.weaponIconColor
    L2_2.weaponIconColor = L3_2
  end
  L2_2 = A0_2.weaponTextColor
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.weaponTextColor
    L2_2.weaponTextColor = L3_2
  end
  L2_2 = A0_2.vehicleControlBorderRadius
  if L2_2 then
    L2_2 = HudSettings
    L3_2 = A0_2.vehicleControlBorderRadius
    L2_2.vehicleControlBorderRadius = L3_2
  end
  L2_2 = A0_2.vehicleControlColors
  if L2_2 then
    L2_2 = HudSettings
    L2_2 = L2_2.vehicleControlColors
    if not L2_2 then
      L2_2 = HudSettings
      L3_2 = {}
      L2_2.vehicleControlColors = L3_2
    end
    L2_2 = pairs
    L3_2 = A0_2.vehicleControlColors
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = HudSettings
      L8_2 = L8_2.vehicleControlColors
      L8_2[L6_2] = L7_2
    end
  end
  L2_2 = L1_1
  L2_2()
  L2_2 = TriggerEvent
  L3_2 = "prism-hud:settingsUpdated"
  L2_2(L3_2)
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L3_1(L4_1, L5_1)
