fx_version 'cerulean'
game 'gta5'
version '1.1.9'
author '_im_hydra#0'
lua54 'yes'

ui_page 'web/build/index.html'

files {
    'web/build/*.*',
    'web/build/**/*.*',
}

shared_scripts {
    'shared/*.lua'
}

client_scripts {
    'client/cl_customize.lua',
    'client/cl_main.lua',
    'client/cl_events.lua',
    'client/cl_functions.lua',
    'client/cl_nui.lua',
    'client/cl_stress.lua',
}

server_scripts {
    'server/*.lua'
}

escrow_ignore {
    'shared/*.lua',
    'client/cl_customize.lua',
    'client/cl_stress.lua',
    'server/sv_customize.lua',
}
dependency '/assetpacks'