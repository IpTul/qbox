Config = {}

Config.Debug = false
Config.Framework = 'qbx' -- qbx or qb or esx
Config.Profile = 'discord' -- discord or steam
Config.PrimaryColor = '#BEEE11' -- Primary accent color for the HUD settings UI

Config.HudSettings = {
    command = 'hudsettings', -- Command to open the HUD settings menu
    keyBind = 'Y' -- Keybind to open the HUD settings menu. make it false to disable
}

Config.VehicleControl = {
    enable = true, -- Enable/disable vehicle control feature
    command = 'vehiclecontrol', -- Command to toggle vehicle control menu
    keyBind = 'Z' -- Keybind to toggle vehicle control menu. make it false to disable
}

Config.VehicleKeybinds = {
    indicatorLeft = {
        enable = true,
        command = 'indicator_left',
        keyBind = 'LEFT' -- Left arrow key. Set to false to disable
    },
    indicatorRight = {
        enable = true,
        command = 'indicator_right',
        keyBind = 'RIGHT' -- Right arrow key. Set to false to disable
    },
    hazard = {
        enable = true,
        command = 'hazard_lights',
        keyBind = 'DOWN' -- Down arrow key. Set to false to disable
    },
    cruiseControl = {
        enable = true,
        command = 'cruise_control',
        keyBind = 'CAPITAL'
    },
    seatbelt = {
        enable = true,
        command = 'seatbelt',
        keyBind = 'B'
    }
}

Config.Seatbelt = {
    Enable = true,
    EjectCheckSpeed = 45,
    RagdollTime = 3,
    VehicleClasses = {0, 1, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 17, 18, 19, 20}
}


-- Player Info (top right)
-- Set any to false to disable that element completely
Config.PlayerInfo = {
    voice = true,
    jobTime = true,
    bankCash = true,
    playerId = true,
    radio = true,
    weapon = true,
}

-- Server Logo
-- Display a server logo on the HUD. Place your logo image as Logo.png in web/build/assets/
-- Players can drag, resize, and toggle visibility in Edit Mode
Config.ServerLogo = {
    enabled = true,           -- Enable/disable server logo display
    width = 60,              -- Default logo width in pixels (at 1080p base)
    height = 60,             -- Default logo height in pixels (at 1080p base)
}

-- Custom Status Bars
-- Add custom stat bars that appear alongside the built-in stats (health, armour, etc.)
-- Other resources can update values via exports: exports['prism-hudv2']:SetCustomStat('hygiene', 80)
Config.CustomStats = {
    -- {
    --     id = 'hygiene',
    --     label = 'Hygiene',
    --     icon = 'droplet',           -- preset name OR raw SVG path data string
    --     defaultValue = 100,
    --     defaultColors = { progress = '#87CEEB', icon = '#87CEEB', background = '#87CEEB' },
    --     stateBag = 'hygiene',       -- optional: auto-listen to this player state bag key
    -- },
}

-- Custom Player Info Fields
-- Add custom info fields that appear alongside the built-in player info (id, job, bank, etc.)
-- Other resources can update values via exports: exports['prism-hudv2']:UpdatePlayerInfoField('gang', 'Ballas - OG')
Config.CustomInfoFields = {
    -- {
    --     id = 'gang',
    --     label = 'Gang',
    --     icon = 'users',             -- preset name OR raw SVG path data string
    --     dataPath = 'gang.label',    -- optional: dot-notation path in PlayerData (framework-specific)
    --     defaultValue = 'None',
    --     stateBag = nil,             -- optional: auto-listen to this player state bag key
    -- },
}

Config.SpeedLimits = {
    enabled = true, -- Enable/disable speed limit zone detection
    checkInterval = 1000, -- How often to check if player is in a zone (ms)
    defaultLimit = 0, -- Default speed limit outside zones (0 = no limit shown)

    zones = {
        -- Legion Square / City Center
        {
            name = "Legion Square",
            coords = vector3(195.0, -933.0, 30.0),
            radius = 800.0,
            speedLimit = 35
        },
        -- Vinewood
        {
            name = "Vinewood",
            coords = vector3(320.0, 180.0, 103.0),
            radius = 600.0,
            speedLimit = 30
        },
        -- Airport
        {
            name = "Airport",
            coords = vector3(-1037.0, -2737.0, 20.0),
            radius = 500.0,
            speedLimit = 25
        },
        -- Highway (Great Ocean Highway)
        {
            name = "Highway",
            coords = vector3(-3041.5010, 242.7639, 15.3506),
            radius = 2000.0,
            speedLimit = 10
        },
    }
}

-- Stress System Configuration
Config.Stress = {
    Enabled = false,              -- Set to false to disable the entire stress system
    MinimumStress = 50,          -- Minimum stress level before screen effects start
    MinimumSpeed = 100,          -- Speed (mph) threshold for gaining stress while driving
    ShootingChance = 0.1,        -- 10% chance to gain stress per shot fired (0.0 - 1.0)
    EnableRagdoll = true,        -- Enable ragdoll falls at max stress (100)
    RagdollChance = 0.5,         -- Chance to ragdoll per effect cycle at max stress (0.0 - 1.0)

    -- Stress relief from consuming food/drink (auto-detected when hunger/thirst increases)
    EatingRelief = 12,           -- Stress removed when player eats food
    DrinkingRelief = 8,          -- Stress removed when player drinks
}

Config.StressEffects = {
    -- How long the blur stays on screen (ms) at each stress tier
    BlurIntensity = {
        [1] = { min = 50, max = 60, intensity = 1500 },
        [2] = { min = 60, max = 70, intensity = 2000 },
        [3] = { min = 70, max = 80, intensity = 2500 },
        [4] = { min = 80, max = 90, intensity = 2700 },
        [5] = { min = 90, max = 100, intensity = 3000 },
    },

    -- Time between effects (ms) - gets shorter as stress rises
    EffectInterval = {
        [1] = { min = 50, max = 60, timeout = math.random(50000, 60000) },
        [2] = { min = 60, max = 70, timeout = math.random(40000, 50000) },
        [3] = { min = 70, max = 80, timeout = math.random(30000, 40000) },
        [4] = { min = 80, max = 90, timeout = math.random(20000, 30000) },
        [5] = { min = 90, max = 100, timeout = math.random(15000, 20000) },
    },
}

-- Locked Settings
-- Add setting keys here to prevent players from changing them.
-- Locked settings always use the value from Config.DefaultHudSettings.
-- Players will see these controls as disabled in the settings menu.
-- Example: Config.LockedSettings = { 'carBikeSpeedometerStyle', 'statsStyle', 'minimapStyle' }
Config.LockedSettings = {}

-- Default HUD Settings (colors and styles)
-- These are used as defaults when player has no saved settings.
-- If you lock a setting above, players will always use the value defined here.
Config.DefaultHudSettings = {
    performanceMode = 'balanced',
    speedUnit = 'mph',
    distanceUnit = 'feet',
    useUltrawide = false,
    showMinimapOnFoot = true,
    showNorthBlip = true,
    moveCompassWhenMinimapHidden = false,
    minimapStyle = 'squaremap',
    showCompassOnFoot = true,
    compassFollowsCamera = true,
    showNearestPostal = false,
    locationDisplayBorderRadius = 'srounded',
    locationDisplayPrimaryColor = '#D9D9D9',
    locationDisplayBackgroundColor = '#161616',
    locationDisplayTextColor = '#C4C4C4',
    statsStyle = 'style1',
    statsColors = {
        health = { progress = '#F98476', icon = '#F98476', background = '#F98476' },
        armour = { progress = '#A5CDFA', icon = '#A5CDFA', background = '#A5CDFA' },
        hunger = { progress = '#F3C08D', icon = '#F3C08D', background = '#F3C08D' },
        thirst = { progress = '#A7EFBC', icon = '#A7EFBC', background = '#A7EFBC' },
        stamina = { progress = '#F7FC9F', icon = '#F7FC9F', background = '#F7FC9F' },
        oxygen = { progress = '#E484A4', icon = '#E484A4', background = '#E484A4' },
        stress = { progress = '#C084FC', icon = '#C084FC', background = '#C084FC' }
    },
    carBikeSpeedometerStyle = 'style1',
    carBikeFlashSpeedLimit = true,
    carBikeIndicatorSounds = true,
    carBikeSpeedLimitStyle = 'us-style',
    carBikeSpeedLimitApproachThreshold = 0.8,
    carBikeSeatbeltWarningSound = true,
    carBikeSeatbeltSound = true,
    speedometerColors = {
        style1 = {
            colours = { rpmArc = '#BEEE11', text = '#FFFFFF' },
            statusColours = { engine = '#F3C08D', fuel = '#E484A4' }
        },
        style2 = {
            colours = { needle = '#DE3134', centerCircle = '#DDDDDD' },
            statusColours = { fuelNeedle = '#DE3134' }
        },
        style3 = {
            colours = { rpmActive = '#D9D9D9', rpmRedZone = '#FF0000', gearBox = '#D9D9D9' },
            statusColours = { indicator = '#00FF00', cruise = '#87CEEB', headlight = '#4169E1', seatbelt = '#5BE48A' }
        },
        style4 = {
            colours = { rpmGradient = '#DE3134', arcFill = '#F2F2F2', text = '#FFFFFF' },
            statusColours = {}
        },
        style5 = {
            colours = { speedNeedle = '#DE3134', rpmNeedle = '#DE3134', fuelNeedle = '#DE3134', arcGradient = '#DE3134' },
            statusColours = { centerCircle = '#DDDDDD' }
        },
        style6 = {
            colours = { text = '#DDDDDD' },
            statusColours = { heart = '#DE3134' }
        }
    },
    bicycleSpeedometerStyle = 'style6',
    bicycleShowSpeedDisplay = true,
    bicycleEnableBellSounds = true,
    bicycleShowCadenceMeter = true,
    bicycleShowHeartRateMonitor = true,
    bicycleSpeedometerColors = {
        style1 = {
            colours = { rpmArc = '#BEEE11', text = '#FFFFFF' },
            statusColours = { engine = '#F3C08D', fuel = '#E484A4' }
        },
        style2 = {
            colours = { needle = '#DE3134', centerCircle = '#DDDDDD' },
            statusColours = { fuelNeedle = '#DE3134' }
        },
        style3 = {
            colours = { rpmActive = '#D9D9D9', rpmRedZone = '#FF0000', gearBox = '#D9D9D9' },
            statusColours = { indicator = '#00FF00', cruise = '#87CEEB', headlight = '#4169E1', seatbelt = '#5BE48A' }
        },
        style4 = {
            colours = { rpmGradient = '#DE3134', arcFill = '#F2F2F2', text = '#FFFFFF' },
            statusColours = {}
        },
        style5 = {
            colours = { speedNeedle = '#DE3134', rpmNeedle = '#DE3134', fuelNeedle = '#DE3134', arcGradient = '#DE3134' },
            statusColours = { centerCircle = '#DDDDDD' }
        },
        style6 = {
            colours = { text = '#DDDDDD' },
            statusColours = { heart = '#DE3134' }
        }
    },
    boatSpeedometerStyle = 'style2',
    boatSpeedometerColors = {
        style1 = {
            colours = { rpmArc = '#BEEE11', text = '#FFFFFF' },
            statusColours = { engine = '#F3C08D', fuel = '#E484A4' }
        },
        style2 = {
            colours = { needle = '#DE3134', centerCircle = '#DDDDDD' },
            statusColours = { fuelNeedle = '#DE3134' }
        },
        style3 = {
            colours = { rpmActive = '#D9D9D9', rpmRedZone = '#FF0000', gearBox = '#D9D9D9' },
            statusColours = { indicator = '#00FF00', cruise = '#87CEEB', headlight = '#4169E1', seatbelt = '#5BE48A' }
        },
        style4 = {
            colours = { rpmGradient = '#DE3134', arcFill = '#F2F2F2', text = '#FFFFFF' },
            statusColours = {}
        },
        style5 = {
            colours = { speedNeedle = '#DE3134', rpmNeedle = '#DE3134', fuelNeedle = '#DE3134', arcGradient = '#DE3134' },
            statusColours = { centerCircle = '#DDDDDD' }
        },
        style6 = {
            colours = { text = '#DDDDDD' },
            statusColours = { heart = '#DE3134' }
        }
    },
    boatShowCompassHeading = true,
    boatEnableHornSounds = true,
    boatShowTrimIndicator = true,
    aircraftSpeedometerStyle = 'style1',
    aircraftSpeedometerColors = {
        style1 = {
            colours = { rpmArc = '#BEEE11', text = '#FFFFFF' },
            statusColours = { engine = '#F3C08D', fuel = '#E484A4' }
        },
        style2 = {
            colours = { needle = '#DE3134', centerCircle = '#DDDDDD' },
            statusColours = { fuelNeedle = '#DE3134' }
        },
        style3 = {
            colours = { rpmActive = '#D9D9D9', rpmRedZone = '#FF0000', gearBox = '#D9D9D9' },
            statusColours = { indicator = '#00FF00', cruise = '#87CEEB', headlight = '#4169E1', seatbelt = '#5BE48A' }
        },
        style4 = {
            colours = { rpmGradient = '#DE3134', arcFill = '#F2F2F2', text = '#FFFFFF' },
            statusColours = {}
        },
        style5 = {
            colours = { speedNeedle = '#DE3134', rpmNeedle = '#DE3134', fuelNeedle = '#DE3134', arcGradient = '#DE3134' },
            statusColours = { centerCircle = '#DDDDDD' }
        },
        style6 = {
            colours = { text = '#DDDDDD' },
            statusColours = { heart = '#DE3134' }
        }
    },
    aircraftShowAltitudeIndicator = true,
    aircraftEnableStallWarning = true,
    aircraftShowArtificialHorizon = true,
    aircraftShowCompassHeading = true,
    trainSpeedometerStyle = 'style3',
    trainSpeedometerColors = {
        style1 = {
            colours = { rpmArc = '#BEEE11', text = '#FFFFFF' },
            statusColours = { engine = '#F3C08D', fuel = '#E484A4' }
        },
        style2 = {
            colours = { needle = '#DE3134', centerCircle = '#DDDDDD' },
            statusColours = { fuelNeedle = '#DE3134' }
        },
        style3 = {
            colours = { rpmActive = '#D9D9D9', rpmRedZone = '#FF0000', gearBox = '#D9D9D9' },
            statusColours = { indicator = '#00FF00', cruise = '#87CEEB', headlight = '#4169E1', seatbelt = '#5BE48A' }
        },
        style4 = {
            colours = { rpmGradient = '#DE3134', arcFill = '#F2F2F2', text = '#FFFFFF' },
            statusColours = {}
        },
        style5 = {
            colours = { speedNeedle = '#DE3134', rpmNeedle = '#DE3134', fuelNeedle = '#DE3134', arcGradient = '#DE3134' },
            statusColours = { centerCircle = '#DDDDDD' }
        },
        style6 = {
            colours = { text = '#DDDDDD' },
            statusColours = { heart = '#DE3134' }
        }
    },
    showPlayerAvatar = true,
    showRadioChannel = true,
    playerVoiceAlignment = 'right',
    playerVoiceBorderRadius = 'slightly',
    voiceChatActiveColor = '#BEEE11',
    voiceChatIdleColor = '#4A4A4A',
    playerInfoBorderRadius = 'slightly',
    playerInfoBackgroundColor = '#161616',
    playerInfoIconColor = '#BEEE11',
    playerInfoTextColor = '#C4C4C4',
    weaponBorderRadius = 'slightly',
    weaponBackgroundColor = '#161616',
    weaponIconColor = '#FFFFFF',
    weaponTextColor = '#C4C4C4',
    vehicleControlBorderRadius = 'slightly',
    vehicleControlColors = {
        backgroundColor = '#161616',
        buttonBackgroundColor = '#262626',
        iconColor = '#FFFFFF',
        statusOnColor = '#BEEE11',
        statusOffColor = '#4A4A4A',
        statusInactiveColor = '#333333',
        textColor = '#C4C4C4',
        badgeColor = '#BEEE11'
    },
    -- Stat visibility thresholds (percentage)
    -- Stats only appear when their value drops to or below this percentage
    -- 100 = always visible, 50 = show when at 50% or below, 0 = never show
    statsThresholds = {
        health = 100,
        armour = 100,
        hunger = 100,
        thirst = 100,
        stamina = 100,
        oxygen = 100,
        stress = 100,
    }
}
